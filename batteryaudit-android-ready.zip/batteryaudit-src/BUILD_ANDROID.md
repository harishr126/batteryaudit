# BatteryAudit Pro – Android build guide

The web app is wrapped with **Capacitor**, so the same code runs as a native Android app
on phones and tablets (rotates, resizes, works offline, camera barcode scanning, and
Excel/CSV/JSON export through the Android share sheet).

## Option A – Build on your computer (Android Studio)
Requires: Node 20+, JDK 21, Android Studio (installs the Android SDK).

```bash
npm install
npm run android:init     # one time: builds web, creates android/, adds camera permission, generates icons
npm run android:open     # opens Android Studio -> Run ▶ on a phone/tablet/emulator
```
Later, after changing the web code:
```bash
npm run android:sync     # rebuild + copy into android/
```
Command-line APK (no Android Studio UI): `npm run android:apk`
-> `android/app/build/outputs/apk/debug/app-debug.apk` (copy to a device and install).

## Option B – Build in the cloud (GitHub Actions)
Push this folder to a GitHub repo, open **Actions -> Build Android APK -> Run workflow**,
then download the `BatteryAuditPro-debug-apk` artifact.

## Play Store / signed release
Android Studio -> Build -> Generate Signed Bundle / APK (choose AAB for Play Store).
Change `appId` in `capacitor.config.ts` before publishing if you want your own package name.

## Notes
* Data lives in the app's local storage on each device (same offline-first behaviour as the web version).
  Use Compilation Hub -> JSON/Excel export to move data between devices. Uninstalling the app erases its data.
* Fonts are bundled, so the app is fully usable with no internet.
