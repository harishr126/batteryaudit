// Run once after `npx cap add android`. Adds camera permission (barcode scanning)
// and makes sure the app works on both phones and tablets.
import fs from 'node:fs';

const manifestPath = 'android/app/src/main/AndroidManifest.xml';
if (!fs.existsSync(manifestPath)) {
  console.error('android/ not found. Run `npx cap add android` first.');
  process.exit(1);
}
let xml = fs.readFileSync(manifestPath, 'utf8');

const additions = [
  ['<uses-permission android:name="android.permission.CAMERA" />', 'android.permission.CAMERA'],
  ['<uses-feature android:name="android.hardware.camera" android:required="false" />', 'android.hardware.camera'],
  ['<uses-feature android:name="android.hardware.camera.autofocus" android:required="false" />', 'camera.autofocus']
];
let block = '';
for (const [line, key] of additions) if (!xml.includes(key)) block += `    ${line}\n`;
if (block) xml = xml.replace('</manifest>', `\n${block}</manifest>`);

// Activity: allow rotation + split-screen/resizing on tablets & foldables, handle keyboard resize.
xml = xml.replace(/<activity\b([^>]*?)>/, (m, attrs) => {
  let a = attrs;
  if (!/android:resizeableActivity/.test(a)) a += '\n            android:resizeableActivity="true"';
  if (!/android:windowSoftInputMode/.test(a)) a += '\n            android:windowSoftInputMode="adjustResize"';
  return `<activity${a}>`;
});

fs.writeFileSync(manifestPath, xml);
console.log('Patched', manifestPath);
