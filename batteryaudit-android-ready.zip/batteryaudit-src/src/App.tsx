import React, { useState, useEffect } from 'react';
import { BatteryEntry, MasterData } from './types/battery';
import { StorageService } from './services/storageService';
import { ExcelService } from './services/excelService';
import { Header } from './components/Header';
import { DataCollectionSheet } from './components/DataCollectionSheet';
import { CompilationHub } from './components/CompilationHub';
import { MasterDataManager } from './components/MasterDataManager';
import { BatteryEntryModal } from './components/BatteryEntryModal';
import { MobileBottomNav } from './components/MobileBottomNav';
import { BarcodeScannerModal } from './components/BarcodeScannerModal';
import { Capacitor } from '@capacitor/core';
import { App as CapApp } from '@capacitor/app';

export default function App() {
  const [entries, setEntries] = useState<BatteryEntry[]>([]);
  const [masterData, setMasterData] = useState<MasterData>(() => StorageService.getMasterData());
  const [activeLocationId, setActiveLocationId] = useState<string>(() => StorageService.getActiveLocationId());
  const [auditorName, setAuditorName] = useState<string>(() => StorageService.getAuditorName());
  const [activeTab, setActiveTab] = useState<'sheet' | 'compilation' | 'masters'>('sheet');

  // Entry Modal
  const [isEntryModalOpen, setIsEntryModalOpen] = useState(false);
  const [editingEntry, setEditingEntry] = useState<BatteryEntry | null>(null);

  // Quick Barcode Scanner from Bottom Nav
  const [isQuickScannerOpen, setIsQuickScannerOpen] = useState(false);

  // Toast / notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Load entries on mount
  useEffect(() => {
    const loaded = StorageService.getEntries();
    setEntries(loaded);
  }, []);

  // Android hardware/gesture back: close the open dialog, else go to Sheet tab, else minimise.
  const backStateRef = React.useRef({ isEntryModalOpen: false, isQuickScannerOpen: false, activeTab: 'sheet' as string });
  backStateRef.current = { isEntryModalOpen, isQuickScannerOpen, activeTab };
  useEffect(() => {
    if (!Capacitor.isNativePlatform()) return;
    const handle = CapApp.addListener('backButton', () => {
      const st = backStateRef.current;
      if (st.isQuickScannerOpen) setIsQuickScannerOpen(false);
      else if (st.isEntryModalOpen) { setIsEntryModalOpen(false); setEditingEntry(null); }
      else if (st.activeTab !== 'sheet') setActiveTab('sheet');
      else CapApp.minimizeApp();
    });
    return () => { handle.then(h => h.remove()); };
  }, []);

  const refreshEntries = () => {
    setEntries(StorageService.getEntries());
  };

  // Location switch
  const handleSelectLocation = (id: string) => {
    setActiveLocationId(id);
    StorageService.setActiveLocationId(id);
    const loc = masterData.locations.find(l => l.id === id);
    showToast(`Switched location to ${loc?.name || id}`);
  };

  // Auditor name update
  const handleUpdateAuditorName = (name: string) => {
    setAuditorName(name);
    StorageService.setAuditorName(name);
    showToast(`Inspector name updated to "${name}"`);
  };

  // Master Data update
  const handleUpdateMasterData = (updated: MasterData) => {
    setMasterData(updated);
    StorageService.saveMasterData(updated);
  };

  // Add / Edit Entry
  const handleSaveEntry = (
    entryData: Omit<BatteryEntry, 'id' | 'createdAt' | 'updatedAt'>,
    saveAndNext: boolean
  ) => {
    if (editingEntry) {
      StorageService.updateEntry(editingEntry.id, entryData);
      showToast(`Updated record #${entryData.srNo} (${entryData.batteryType})`);
      setEditingEntry(null);
    } else {
      StorageService.addEntry({
        ...entryData,
        auditorName
      });
      showToast(`Added battery row #${entryData.srNo} (${entryData.batteryType})`);
    }

    refreshEntries();

    if (!saveAndNext) {
      setIsEntryModalOpen(false);
    }
  };

  // Duplicate an entry
  const handleDuplicateEntry = (source: BatteryEntry) => {
    const nextSr = StorageService.getNextSrNo(source.locationId);
    setEditingEntry({
      ...source,
      id: '', // new id
      srNo: nextSr,
      productionCode: '', // clear serial code for new battery unit
      remarks: source.remarks ? `${source.remarks} (Batch unit)` : ''
    });
    setIsEntryModalOpen(true);
  };

  // Delete entry
  const handleDeleteEntry = (id: string) => {
    StorageService.deleteEntry(id);
    refreshEntries();
    showToast('Battery entry deleted');
  };

  // Delete multiple entries
  const handleDeleteMultiple = (ids: string[]) => {
    StorageService.deleteMultipleEntries(ids);
    refreshEntries();
    showToast(`Deleted ${ids.length} battery entries`);
  };

  // Inline Qty adjustment (+ / -)
  const handleUpdateQty = (id: string, delta: number) => {
    const target = entries.find(e => e.id === id);
    if (!target) return;
    const newQty = Math.max(0, target.qty + delta);
    StorageService.updateEntry(id, { qty: newQty });
    refreshEntries();
  };

  // Import file (Excel, CSV)
  const handleImportFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const activeLoc = masterData.locations.find(l => l.id === activeLocationId) || masterData.locations[0];
      const parsed = await ExcelService.parseFile(file, activeLoc.id, activeLoc.name);
      const result = StorageService.mergeExternalEntries(parsed);
      refreshEntries();
      showToast(`Imported ${result.added} battery entries into ${activeLoc.name}!`);
    } catch (err: any) {
      alert('Error importing spreadsheet: ' + (err.message || 'Check file columns'));
    }
    e.target.value = '';
  };

  // Handle scanned barcode from mobile quick scanner
  const handleScannedCodeFromFAB = (code: string) => {
    // Check if an existing entry with this production code already exists
    const match = entries.find(e => e.productionCode.toUpperCase() === code.toUpperCase());
    if (match) {
      if (window.confirm(`Found existing battery record #${match.srNo} (${match.batteryType} - ${match.brand}) for code "${code}". Open for edit?`)) {
        setEditingEntry(match);
        setIsEntryModalOpen(true);
        return;
      }
    }

    // Open new entry with this code pre-filled
    const nextSr = StorageService.getNextSrNo(activeLocationId);
    setEditingEntry({
      id: '',
      srNo: nextSr,
      batteryType: masterData.batteryTypes[0] || 'N50 MF',
      brand: masterData.brands[0] || 'CHARGER GOLD',
      specification: masterData.specifications[0] || 'RB',
      qty: 1,
      status: masterData.statuses[0] || 'DRY',
      colour: masterData.colours[0]?.name || 'Plain',
      productionCode: code,
      monthOfCharge: 'OCT/24',
      remarks: '',
      locationId: activeLocationId,
      locationName: masterData.locations.find(l => l.id === activeLocationId)?.name || 'Plant 1',
      createdAt: '',
      updatedAt: ''
    });
    setIsEntryModalOpen(true);
  };

  const activeLoc = masterData.locations.find(l => l.id === activeLocationId) || masterData.locations[0];
  const currentLocCount = entries.filter(e => e.locationId === activeLocationId).length;
  const nextSrNo = StorageService.getNextSrNo(activeLocationId);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans antialiased pb-20 sm:pb-6 selection:bg-blue-600 selection:text-white">
      
      {/* App Header & Navigation */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        locations={masterData.locations}
        activeLocationId={activeLocationId}
        onSelectLocation={handleSelectLocation}
        auditorName={auditorName}
        onUpdateAuditorName={handleUpdateAuditorName}
        totalEntriesCount={entries.length}
        currentLocCount={currentLocCount}
        onQuickAdd={() => {
          setEditingEntry(null);
          setIsEntryModalOpen(true);
        }}
      />

      {/* Toast notification banner */}
      {toastMessage && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 bg-blue-600 text-white text-xs font-bold px-4 py-2 rounded-full shadow-2xl border border-blue-400 animate-in fade-in slide-in-from-top-2">
          {toastMessage}
        </div>
      )}

      {/* Main Content Area */}
      <main className="max-w-7xl w-full mx-auto px-3 sm:px-6 py-4 flex-1">
        {activeTab === 'sheet' && (
          <DataCollectionSheet
            entries={entries}
            masterData={masterData}
            activeLocationId={activeLocationId}
            onAddEntry={() => {
              setEditingEntry(null);
              setIsEntryModalOpen(true);
            }}
            onEditEntry={(entry) => {
              setEditingEntry(entry);
              setIsEntryModalOpen(true);
            }}
            onDuplicateEntry={handleDuplicateEntry}
            onDeleteEntry={handleDeleteEntry}
            onDeleteMultiple={handleDeleteMultiple}
            onUpdateQty={handleUpdateQty}
            onImportFile={handleImportFile}
          />
        )}

        {activeTab === 'compilation' && (
          <CompilationHub
            entries={entries}
            locations={masterData.locations}
            masterData={masterData}
            onRefreshEntries={refreshEntries}
          />
        )}

        {activeTab === 'masters' && (
          <MasterDataManager
            masterData={masterData}
            onUpdateMasterData={handleUpdateMasterData}
          />
        )}
      </main>

      {/* Mobile-First Bottom Navigation Bar */}
      <MobileBottomNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onAddEntry={() => {
          setEditingEntry(null);
          setIsEntryModalOpen(true);
        }}
        onOpenScanner={() => setIsQuickScannerOpen(true)}
        currentLocName={activeLoc?.code || 'LOC'}
      />

      {/* Battery Entry / Edit Modal */}
      <BatteryEntryModal
        isOpen={isEntryModalOpen}
        onClose={() => {
          setIsEntryModalOpen(false);
          setEditingEntry(null);
        }}
        onSave={handleSaveEntry}
        editingEntry={editingEntry}
        masterData={masterData}
        activeLocationId={activeLocationId}
        defaultSrNo={nextSrNo}
      />

      {/* Camera Barcode Scanner triggered from mobile FAB */}
      <BarcodeScannerModal
        isOpen={isQuickScannerOpen}
        onClose={() => setIsQuickScannerOpen(false)}
        onScan={handleScannedCodeFromFAB}
      />
    </div>
  );
}
