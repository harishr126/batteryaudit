import React, { useEffect, useRef, useState } from 'react';
import { Camera, X, RefreshCw, AlertCircle, Check, Zap } from 'lucide-react';
import { BrowserMultiFormatReader } from '@zxing/browser';

interface BarcodeScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScan: (code: string) => void;
}

export const BarcodeScannerModal: React.FC<BarcodeScannerModalProps> = ({ isOpen, onClose, onScan }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [error, setError] = useState<string | null>(null);
  const [manualCode, setManualCode] = useState('');
  const [cameras, setCameras] = useState<MediaDeviceInfo[]>([]);
  const [selectedCameraId, setSelectedCameraId] = useState<string>('');
  const [torchOn, setTorchOn] = useState(false);
  const codeReaderRef = useRef<BrowserMultiFormatReader | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Play subtle beep sound on successful scan
  const playBeep = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, audioCtx.currentTime); // A5 note
      gain.gain.setValueAtTime(0.2, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.15);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.15);
    } catch {
      // Audio not permitted or supported
    }
  };

  useEffect(() => {
    if (!isOpen) {
      stopScanning();
      return;
    }

    let isMounted = true;

    async function initCamera() {
      try {
        setError(null);
        codeReaderRef.current = new BrowserMultiFormatReader();

        // Ask for camera permission up-front (triggers the Android runtime prompt in the app).
        // Device labels are empty until permission is granted, which breaks rear-camera selection.
        try {
          const warmup = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
          warmup.getTracks().forEach(t => t.stop());
        } catch (permErr) {
          if (!isMounted) return;
          throw permErr;
        }
        if (!isMounted) return;

        // Enumerate video devices
        const devices = await BrowserMultiFormatReader.listVideoInputDevices();
        if (!isMounted) return;

        setCameras(devices);
        
        // Select back/rear camera if available
        const backCam = devices.find(d => 
          d.label.toLowerCase().includes('back') || 
          d.label.toLowerCase().includes('rear') ||
          d.label.toLowerCase().includes('environment')
        );
        const deviceId = backCam ? backCam.deviceId : (devices[0]?.deviceId || '');
        setSelectedCameraId(deviceId);

        if (videoRef.current && deviceId) {
          startDecoding(deviceId);
        } else if (videoRef.current && devices.length === 0) {
          // Try standard getUserMedia as fallback
          const stream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: 'environment' }
          });
          streamRef.current = stream;
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
            videoRef.current.play();
          }
        }
      } catch (err: any) {
        if (!isMounted) return;
        console.warn('Camera access issue:', err);
        setError('Camera access unavailable or blocked. You can manually enter or paste the battery production code below.');
      }
    }

    initCamera();

    return () => {
      isMounted = false;
      stopScanning();
    };
  }, [isOpen]);

  const startDecoding = async (deviceId: string) => {
    try {
      if (!codeReaderRef.current || !videoRef.current) return;
      await codeReaderRef.current.decodeFromVideoDevice(
        deviceId,
        videoRef.current,
        (result, err) => {
          if (result) {
            const text = result.getText();
            if (text) {
              playBeep();
              onScan(text);
              onClose();
            }
          }
        }
      );
    } catch (err: any) {
      console.warn('Decoder start error:', err);
      setError('Unable to stream camera feed: ' + (err.message || 'Check permissions.'));
    }
  };

  const stopScanning = () => {
    if (codeReaderRef.current) {
      try {
        // Stop continuous decoding if method exists
        (codeReaderRef.current as any).reset?.();
      } catch {
        // ignore
      }
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }
    if (videoRef.current && videoRef.current.srcObject) {
      const s = videoRef.current.srcObject as MediaStream;
      s.getTracks().forEach(t => t.stop());
      videoRef.current.srcObject = null;
    }
  };

  const toggleTorch = async () => {
    try {
      if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        const track = stream.getVideoTracks()[0];
        const capabilities: any = track.getCapabilities?.() || {};
        if (capabilities.torch) {
          const next = !torchOn;
          await (track as any).applyConstraints({
            advanced: [{ torch: next }]
          });
          setTorchOn(next);
        }
      }
    } catch {
      // ignore
    }
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (manualCode.trim()) {
      onScan(manualCode.trim().toUpperCase());
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md">
      <div 
        className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-3xl shadow-2xl overflow-hidden flex flex-col text-white animate-in fade-in zoom-in-95 duration-150"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 bg-slate-800/90 border-b border-slate-700">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-blue-600/30 text-blue-400 rounded-xl border border-blue-500/30">
              <Camera className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">Scan Battery Barcode</h3>
              <p className="text-xs text-slate-400">Position barcode / QR code in view</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Video Viewport */}
        <div className="relative bg-black w-full aspect-4/3 flex items-center justify-center overflow-hidden">
          {error ? (
            <div className="p-6 text-center max-w-xs">
              <AlertCircle className="w-10 h-10 text-amber-400 mx-auto mb-2" />
              <p className="text-xs text-slate-300 leading-relaxed mb-3">{error}</p>
              <p className="text-xs text-blue-400">Use manual code entry below</p>
            </div>
          ) : (
            <>
              <video
                ref={videoRef}
                className="w-full h-full object-cover"
                playsInline
                autoPlay
                muted
              />
              {/* Scan target reticle overlay */}
              <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                <div className="w-64 h-36 border-2 border-dashed border-blue-400/80 rounded-2xl relative shadow-[0_0_0_9999px_rgba(0,0,0,0.5)]">
                  <div className="absolute top-0 left-0 w-4 h-4 border-t-4 border-l-4 border-blue-400 -mt-1 -ml-1 rounded-tl-lg" />
                  <div className="absolute top-0 right-0 w-4 h-4 border-t-4 border-r-4 border-blue-400 -mt-1 -mr-1 rounded-tr-lg" />
                  <div className="absolute bottom-0 left-0 w-4 h-4 border-b-4 border-l-4 border-blue-400 -mb-1 -ml-1 rounded-bl-lg" />
                  <div className="absolute bottom-0 right-0 w-4 h-4 border-b-4 border-r-4 border-blue-400 -mb-1 -mr-1 rounded-br-lg" />
                  <div className="absolute inset-x-2 top-1/2 h-0.5 bg-red-500/80 animate-pulse shadow-sm shadow-red-500" />
                </div>
              </div>

              {/* Torch button if supported */}
              <button
                type="button"
                onClick={toggleTorch}
                className={`absolute top-3 right-3 p-2.5 rounded-full backdrop-blur-md transition-all ${
                  torchOn ? 'bg-amber-500 text-black shadow-lg shadow-amber-500/50' : 'bg-black/60 text-white hover:bg-black/80'
                }`}
                title="Toggle Torch / Flashlight"
              >
                <Zap className="w-5 h-5" />
              </button>
            </>
          )}
        </div>

        {/* Camera Selector (if multiple) */}
        {cameras.length > 1 && !error && (
          <div className="px-4 py-2 bg-slate-800/60 border-b border-slate-800 flex items-center justify-between text-xs">
            <span className="text-slate-400">Camera:</span>
            <select
              value={selectedCameraId}
              onChange={(e) => {
                const newId = e.target.value;
                setSelectedCameraId(newId);
                stopScanning();
                startDecoding(newId);
              }}
              className="bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded-lg px-2 py-1 max-w-[200px] truncate"
            >
              {cameras.map((c, i) => (
                <option key={c.deviceId || i} value={c.deviceId}>
                  {c.label || `Camera ${i + 1}`}
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Manual Code Input Option */}
        <div className="p-4 bg-slate-900">
          <form onSubmit={handleManualSubmit} className="space-y-3">
            <label className="text-xs font-semibold text-slate-300 block">
              Or Type / Paste Battery Production Code:
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={manualCode}
                onChange={(e) => setManualCode(e.target.value)}
                placeholder="e.g. CG50-202410-A1, 9844-WH"
                className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-sm font-mono text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
              />
              <button
                type="submit"
                disabled={!manualCode.trim()}
                className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition-all"
              >
                <Check className="w-4 h-4" /> Use Code
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
