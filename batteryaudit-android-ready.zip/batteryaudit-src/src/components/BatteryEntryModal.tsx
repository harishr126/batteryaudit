import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  X, Check, Plus, Minus, Camera, Calendar, Hash, Tag, Layers, 
  BatteryCharging, Palette, Barcode, MessageSquare, MapPin, 
  Search, ArrowRight, Sparkles 
} from 'lucide-react';
import { BatteryEntry, MasterData } from '../types/battery';
import { MonthYearPicker } from './MonthYearPicker';
import { BarcodeScannerModal } from './BarcodeScannerModal';

interface BatteryEntryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (entry: Omit<BatteryEntry, 'id' | 'createdAt' | 'updatedAt'>, saveAndNext: boolean) => void;
  editingEntry?: BatteryEntry | null;
  masterData: MasterData;
  activeLocationId: string;
  defaultSrNo: number;
}

export const BatteryEntryModal: React.FC<BatteryEntryModalProps> = ({
  isOpen,
  onClose,
  onSave,
  editingEntry,
  masterData,
  activeLocationId,
  defaultSrNo
}) => {
  const activeLoc = masterData.locations.find(l => l.id === activeLocationId) || masterData.locations[0];

  const [srNo, setSrNo] = useState<number>(defaultSrNo);
  const [batteryType, setBatteryType] = useState<string>(masterData.batteryTypes[0] || 'N50 MF');
  const [brand, setBrand] = useState<string>(masterData.brands[0] || 'CHARGER GOLD');
  const [specification, setSpecification] = useState<string>(masterData.specifications[0] || 'RB');
  const [qty, setQty] = useState<number>(1);
  const [status, setStatus] = useState<string>(masterData.statuses[0] || 'DRY');
  const [colour, setColour] = useState<string>(masterData.colours[0]?.name || 'Plain');
  const [productionCode, setProductionCode] = useState<string>('');
  const [monthOfCharge, setMonthOfCharge] = useState<string>('OCT/24');
  const [remarks, setRemarks] = useState<string>('');
  const [locationId, setLocationId] = useState<string>(activeLocationId);

  // Search & Typeahead for 100+ Battery Types
  const [typeSearch, setTypeSearch] = useState('');
  const [isTypeDropdownOpen, setIsTypeDropdownOpen] = useState(false);
  const typeDropdownRef = useRef<HTMLDivElement>(null);

  // Month-Year Picker modal
  const [isMonthPickerOpen, setIsMonthPickerOpen] = useState(false);

  // Barcode Scanner modal
  const [isScannerOpen, setIsScannerOpen] = useState(false);

  // Validation errors
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  // Initialize form state
  useEffect(() => {
    if (editingEntry) {
      setSrNo(editingEntry.srNo);
      setBatteryType(editingEntry.batteryType);
      setBrand(editingEntry.brand);
      setSpecification(editingEntry.specification);
      setQty(editingEntry.qty);
      setStatus(editingEntry.status);
      setColour(editingEntry.colour);
      setProductionCode(editingEntry.productionCode || '');
      setMonthOfCharge(editingEntry.monthOfCharge || 'OCT/24');
      setRemarks(editingEntry.remarks || '');
      setLocationId(editingEntry.locationId);
    } else {
      setSrNo(defaultSrNo);
      setQty(1);
      setProductionCode('');
      setRemarks('');
      setLocationId(activeLocationId);
    }
  }, [editingEntry, defaultSrNo, activeLocationId]);

  // Click outside listener for typeahead
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (typeDropdownRef.current && !typeDropdownRef.current.contains(e.target as Node)) {
        setIsTypeDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Filter battery types based on search
  const filteredBatteryTypes = useMemo(() => {
    if (!typeSearch.trim()) return masterData.batteryTypes;
    const term = typeSearch.toLowerCase().trim();
    return masterData.batteryTypes.filter(t => t.toLowerCase().includes(term));
  }, [masterData.batteryTypes, typeSearch]);

  const validate = () => {
    const errs: { [key: string]: string } = {};
    if (!batteryType) errs.batteryType = 'Battery type is required';
    if (!brand) errs.brand = 'Brand is required';
    if (!specification) errs.specification = 'Specification is required';
    if (qty < 0 || isNaN(qty)) errs.qty = 'Quantity must be a positive number';
    if (!status) errs.status = 'Status is required';
    if (!colour) errs.colour = 'Colour is required';
    if (!monthOfCharge) errs.monthOfCharge = 'Month of charge is required (MMM/YY)';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (saveAndNext: boolean = false) => {
    if (!validate()) return;

    const loc = masterData.locations.find(l => l.id === locationId) || activeLoc;

    onSave({
      srNo: Number(srNo) || 1,
      batteryType,
      brand,
      specification,
      qty: Math.max(0, Math.floor(Number(qty) || 0)),
      status,
      colour,
      productionCode: productionCode.trim().toUpperCase(),
      monthOfCharge: monthOfCharge.trim().toUpperCase(),
      remarks: remarks.trim(),
      locationId: loc.id,
      locationName: loc.name
    }, saveAndNext);

    if (saveAndNext) {
      // Auto-increment Sr No and clear per-unit fields for next entry
      setSrNo(prev => prev + 1);
      setProductionCode('');
      setRemarks('');
    } else {
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 z-40 flex items-center justify-center p-2 sm:p-4 bg-black/75 backdrop-blur-xs overflow-y-auto">
        <div 
          className="w-full max-w-2xl bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden my-auto text-slate-100 flex flex-col max-h-[92vh]"
          onClick={e => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between px-5 py-4 bg-slate-800/90 border-b border-slate-700 sticky top-0 z-20">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20 font-bold text-lg">
                {editingEntry ? '✎' : '+'}
              </div>
              <div>
                <h2 className="text-base sm:text-lg font-bold text-white tracking-tight">
                  {editingEntry ? 'Edit Battery Record' : 'New Battery Entry'}
                </h2>
                <div className="flex items-center gap-2 text-xs text-slate-400">
                  <span className="flex items-center gap-1 text-blue-400 font-medium">
                    <MapPin className="w-3.5 h-3.5" />
                    {activeLoc?.name}
                  </span>
                  <span>•</span>
                  <span>Format: 10 Standard Fields</span>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-700/70 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body Form */}
          <div className="p-4 sm:p-6 overflow-y-auto space-y-5 flex-1">
            
            {/* Row 1: Sr No & Location */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5 mb-1.5">
                  <Hash className="w-3.5 h-3.5 text-blue-400" />
                  1. Sr No (Serial)
                </label>
                <input
                  type="number"
                  min="1"
                  value={srNo}
                  onChange={(e) => setSrNo(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-full bg-slate-800/90 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm font-mono font-bold text-white focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5 mb-1.5">
                  <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                  Audit Location
                </label>
                <select
                  value={locationId}
                  onChange={(e) => setLocationId(e.target.value)}
                  className="w-full bg-slate-800/90 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm font-medium text-white focus:outline-none focus:border-blue-500"
                >
                  {masterData.locations.map(loc => (
                    <option key={loc.id} value={loc.id}>
                      {loc.name} ({loc.code})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Row 2: Battery Type (Searchable Typeahead for 100+ types) */}
            <div className="relative" ref={typeDropdownRef}>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <Tag className="w-3.5 h-3.5 text-amber-400" />
                  2. Battery Type (100+ Catalog)
                </label>
                <span className="text-[11px] text-blue-400 font-medium">
                  {masterData.batteryTypes.length} types available
                </span>
              </div>

              {/* Display button / search trigger */}
              <div 
                onClick={() => setIsTypeDropdownOpen(!isTypeDropdownOpen)}
                className="w-full bg-slate-800 border border-slate-700 hover:border-slate-600 rounded-xl px-3.5 py-2.5 flex items-center justify-between cursor-pointer transition-all shadow-inner"
              >
                <div className="flex items-center gap-2">
                  <span className="font-mono font-bold text-blue-300 text-sm">{batteryType}</span>
                </div>
                <span className="text-xs text-slate-400 bg-slate-700/60 px-2 py-0.5 rounded-md">
                  Change / Search
                </span>
              </div>

              {/* Typeahead Dropdown Menu */}
              {isTypeDropdownOpen && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-slate-800 border border-slate-600 rounded-2xl shadow-2xl z-30 p-2 overflow-hidden animate-in fade-in duration-100">
                  <div className="relative mb-2">
                    <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                    <input
                      type="text"
                      placeholder="Type to filter e.g. N50, NS40, 58043..."
                      value={typeSearch}
                      onChange={(e) => setTypeSearch(e.target.value)}
                      autoFocus
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500 font-mono"
                    />
                  </div>

                  <div className="max-h-56 overflow-y-auto space-y-1 pr-1">
                    {filteredBatteryTypes.map(t => (
                      <button
                        key={t}
                        type="button"
                        onClick={() => {
                          setBatteryType(t);
                          setIsTypeDropdownOpen(false);
                          setTypeSearch('');
                        }}
                        className={`w-full text-left px-3 py-2 rounded-xl text-xs font-mono font-semibold flex items-center justify-between transition-colors ${
                          batteryType === t 
                            ? 'bg-blue-600 text-white' 
                            : 'text-slate-200 hover:bg-slate-700/80 hover:text-white'
                        }`}
                      >
                        <span>{t}</span>
                        {batteryType === t && <Check className="w-3.5 h-3.5" />}
                      </button>
                    ))}
                    {filteredBatteryTypes.length === 0 && (
                      <div className="p-3 text-center text-xs text-slate-400">
                        No matches found.
                        <button
                          type="button"
                          onClick={() => {
                            if (typeSearch.trim()) {
                              setBatteryType(typeSearch.trim().toUpperCase());
                              setIsTypeDropdownOpen(false);
                            }
                          }}
                          className="block mx-auto mt-2 text-blue-400 underline font-semibold"
                        >
                          Use "{typeSearch.trim().toUpperCase()}" as new type
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Row 3: Brand & Specification */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5 mb-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                  3. Brand (20 Types)
                </label>
                <select
                  value={brand}
                  onChange={(e) => setBrand(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm font-semibold text-white focus:outline-none focus:border-blue-500"
                >
                  {masterData.brands.map(b => (
                    <option key={b} value={b}>{b}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5 mb-1.5">
                  <Layers className="w-3.5 h-3.5 text-cyan-400" />
                  4. Specification (~12 Types)
                </label>
                <select
                  value={specification}
                  onChange={(e) => setSpecification(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm font-semibold text-white focus:outline-none focus:border-blue-500"
                >
                  {masterData.specifications.map(s => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Row 4: Quantity (Touch +/- steppers and Quick Presets) */}
            <div>
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5 mb-1.5">
                <Hash className="w-3.5 h-3.5 text-green-400" />
                5. Quantity (Qty no's)
              </label>
              
              <div className="flex flex-col sm:flex-row gap-2">
                <div className="flex items-center bg-slate-800 border border-slate-700 rounded-xl p-1 w-full sm:w-60">
                  <button
                    type="button"
                    onClick={() => setQty(q => Math.max(1, q - 1))}
                    className="w-10 h-10 rounded-lg bg-slate-700/80 hover:bg-slate-600 text-white flex items-center justify-center font-bold text-lg active:scale-90 transition-transform"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <input
                    type="number"
                    min="0"
                    value={qty}
                    onChange={(e) => setQty(Math.max(0, parseInt(e.target.value) || 0))}
                    className="flex-1 bg-transparent text-center font-mono font-bold text-lg text-white focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setQty(q => q + 1)}
                    className="w-10 h-10 rounded-lg bg-blue-600 hover:bg-blue-500 text-white flex items-center justify-center font-bold text-lg active:scale-90 transition-transform"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>

                {/* Quick counting increment chips */}
                <div className="flex items-center gap-1.5 overflow-x-auto py-1">
                  {[5, 10, 24, 36, 48, 100].map(addVal => (
                    <button
                      key={addVal}
                      type="button"
                      onClick={() => setQty(q => q + addVal)}
                      className="px-2.5 py-2 text-xs font-mono font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors shrink-0"
                    >
                      +{addVal}
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={() => setQty(1)}
                    className="px-2 py-2 text-xs font-semibold rounded-lg text-slate-400 hover:text-slate-200 transition-colors shrink-0"
                  >
                    Reset (1)
                  </button>
                </div>
              </div>
            </div>

            {/* Row 5: Status (4 types) */}
            <div>
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5 mb-2">
                <BatteryCharging className="w-3.5 h-3.5 text-blue-400" />
                6. Status (4 Types)
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {masterData.statuses.map(st => {
                  const isSelected = status === st;
                  let badgeColor = 'bg-slate-800 text-slate-300 border-slate-700';
                  if (isSelected) {
                    if (st.includes('Fresh')) badgeColor = 'bg-emerald-600 text-white border-emerald-400 ring-2 ring-emerald-400/40';
                    else if (st.includes('Normal')) badgeColor = 'bg-blue-600 text-white border-blue-400 ring-2 ring-blue-400/40';
                    else if (st.includes('Needs')) badgeColor = 'bg-amber-600 text-white border-amber-400 ring-2 ring-amber-400/40';
                    else badgeColor = 'bg-rose-600 text-white border-rose-400 ring-2 ring-rose-400/40';
                  }

                  return (
                    <button
                      key={st}
                      type="button"
                      onClick={() => setStatus(st)}
                      className={`p-2.5 rounded-xl text-xs font-bold border transition-all text-left flex flex-col justify-between ${badgeColor}`}
                    >
                      <span className="line-clamp-2">{st}</span>
                      {isSelected && <Check className="w-3.5 h-3.5 self-end mt-1" />}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Row 6: Box Colour (6 types) */}
            <div>
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5 mb-2">
                <Palette className="w-3.5 h-3.5 text-pink-400" />
                7. Battery Box Colour (6 Types)
              </label>
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                {masterData.colours.map(col => {
                  const isSelected = colour === col.name;
                  return (
                    <button
                      key={col.name}
                      type="button"
                      onClick={() => setColour(col.name)}
                      className={`py-2 px-2.5 rounded-xl border flex items-center gap-2 transition-all ${
                        isSelected 
                          ? 'bg-slate-800 border-blue-400 ring-2 ring-blue-400/40' 
                          : 'bg-slate-800/60 border-slate-700 hover:bg-slate-800'
                      }`}
                    >
                      <span 
                        className="w-4 h-4 rounded-full border border-black/30 shadow-xs shrink-0" 
                        style={{ backgroundColor: col.hex }}
                      />
                      <span className="text-xs font-semibold text-slate-200 truncate">{col.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Row 7: Production Code & Month of Charge */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Production Code */}
              <div>
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5 mb-1.5">
                  <Barcode className="w-3.5 h-3.5 text-indigo-400" />
                  8. Production Code (Alphanumeric)
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={productionCode}
                    onChange={(e) => setProductionCode(e.target.value.toUpperCase())}
                    placeholder="e.g. CG50-202410-A1"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-3.5 pr-12 py-2.5 text-sm font-mono text-white placeholder-slate-500 uppercase focus:outline-none focus:border-blue-500"
                  />
                  <button
                    type="button"
                    onClick={() => setIsScannerOpen(true)}
                    className="absolute right-1.5 top-1.5 bottom-1.5 px-2 bg-blue-600/30 hover:bg-blue-600 text-blue-300 hover:text-white rounded-lg flex items-center justify-center transition-colors"
                    title="Scan Barcode with Camera"
                  >
                    <Camera className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Month of Charge (MMM/YY) */}
              <div>
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5 mb-1.5">
                  <Calendar className="w-3.5 h-3.5 text-teal-400" />
                  9. Month of Charge (MMM/YY)
                </label>
                <div 
                  onClick={() => setIsMonthPickerOpen(true)}
                  className="w-full bg-slate-800 border border-slate-700 hover:border-slate-600 rounded-xl px-3.5 py-2.5 flex items-center justify-between cursor-pointer transition-colors"
                >
                  <span className="font-mono font-bold text-emerald-400 text-sm">
                    {monthOfCharge || 'SELECT'}
                  </span>
                  <span className="text-xs text-slate-400 flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5" />
                    Change
                  </span>
                </div>
              </div>
            </div>

            {/* Row 8: Remarks */}
            <div>
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5 mb-1.5">
                <MessageSquare className="w-3.5 h-3.5 text-slate-400" />
                10. Remarks (Optional Notes)
              </label>
              <input
                type="text"
                value={remarks}
                onChange={(e) => setRemarks(e.target.value)}
                placeholder="e.g. Pallet #04, voltage 12.78V, dry storage bay B-2, export ready"
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
              />
              
              {/* Quick remark pills */}
              <div className="flex items-center gap-1.5 overflow-x-auto mt-2 pb-1">
                {['Pre-charged OK', 'Dry storage bay', 'Tested 12.6V+', 'Needs boost charge', 'Export pallet'].map(pill => (
                  <button
                    key={pill}
                    type="button"
                    onClick={() => setRemarks(r => r ? `${r}; ${pill}` : pill)}
                    className="px-2 py-1 text-[11px] rounded-md bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 border border-slate-700/60 shrink-0 transition-colors"
                  >
                    + {pill}
                  </button>
                ))}
              </div>
            </div>

          </div>

          {/* Footer Actions */}
          <div className="px-5 py-4 bg-slate-800/90 border-t border-slate-700 flex flex-col sm:flex-row items-center justify-between gap-3 sticky bottom-0 z-20">
            <button
              type="button"
              onClick={onClose}
              className="w-full sm:w-auto px-4 py-2.5 text-xs font-semibold text-slate-400 hover:text-white rounded-xl hover:bg-slate-700 transition-colors"
            >
              Cancel
            </button>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              {!editingEntry && (
                <button
                  type="button"
                  onClick={() => handleSubmit(true)}
                  className="flex-1 sm:flex-initial px-4 py-2.5 bg-slate-700 hover:bg-slate-600 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 border border-slate-600 transition-all active:scale-95"
                >
                  <span>Save &amp; Add Next</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}

              <button
                type="button"
                onClick={() => handleSubmit(false)}
                className="flex-1 sm:flex-initial px-5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-lg shadow-blue-600/30 transition-all active:scale-95"
              >
                <Check className="w-4 h-4" />
                <span>{editingEntry ? 'Update Entry' : 'Save Entry'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Month Year Picker Popover */}
      <MonthYearPicker
        isOpen={isMonthPickerOpen}
        value={monthOfCharge}
        onChange={(val) => setMonthOfCharge(val)}
        onClose={() => setIsMonthPickerOpen(false)}
      />

      {/* Camera Barcode Scanner */}
      <BarcodeScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        onScan={(code) => setProductionCode(code)}
      />
    </>
  );
};
