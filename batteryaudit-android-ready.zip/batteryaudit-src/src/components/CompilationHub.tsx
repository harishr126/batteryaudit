import React, { useState, useMemo } from 'react';
import { deliverFile } from '../services/nativeFile';
import { 
  Building2, Layers, Download, Upload, FileSpreadsheet, CheckCircle2, 
  Share2, ArrowUpDown, Filter, ChevronRight, BarChart2, PieChart, 
  MapPin, AlertCircle, Copy, Check 
} from 'lucide-react';
import { BatteryEntry, LocationInfo, MasterData } from '../types/battery';
import { ExcelService } from '../services/excelService';
import { StorageService } from '../services/storageService';

interface CompilationHubProps {
  entries: BatteryEntry[];
  locations: LocationInfo[];
  masterData: MasterData;
  onRefreshEntries: () => void;
}

export const CompilationHub: React.FC<CompilationHubProps> = ({
  entries,
  locations,
  masterData,
  onRefreshEntries
}) => {
  const [selectedFilterLoc, setSelectedFilterLoc] = useState<string>('ALL');
  const [importStatus, setImportStatus] = useState<{ message: string; type: 'success' | 'error' } | null>(null);
  const [copiedJson, setCopiedJson] = useState(false);

  // Consolidated statistics
  const summary = useMemo(() => {
    const totalQty = entries.reduce((acc, curr) => acc + (Number(curr.qty) || 0), 0);

    // Location breakdown
    const locMap = locations.map(loc => {
      const locEntries = entries.filter(e => e.locationId === loc.id);
      const locQty = locEntries.reduce((acc, curr) => acc + (Number(curr.qty) || 0), 0);
      return {
        ...loc,
        recordCount: locEntries.length,
        totalQty: locQty
      };
    });

    // Status breakdown (DRY, MF, WET, Under Charging)
    const statusMap = masterData.statuses.map(st => {
      const count = entries.filter(e => e.status === st).reduce((acc, curr) => acc + (Number(curr.qty) || 0), 0);
      return {
        status: st,
        quantity: count,
        percent: totalQty > 0 ? Math.round((count / totalQty) * 100) : 0
      };
    });

    // Brand breakdown
    const brandMap: Record<string, number> = {};
    entries.forEach(e => {
      brandMap[e.brand] = (brandMap[e.brand] || 0) + (Number(e.qty) || 0);
    });
    const brandList = Object.entries(brandMap)
      .map(([brand, qty]) => ({ brand, qty }))
      .sort((a, b) => b.qty - a.qty);

    // Battery Type & Spec cross-tabulation
    const typeMap = new Map<string, {
      batteryType: string;
      specification: string;
      brand: string;
      colour: string;
      totalQty: number;
      locQty: Record<string, number>;
    }>();

    entries.forEach(e => {
      const key = `${e.batteryType}___${e.specification}___${e.brand}___${e.colour}`;
      if (!typeMap.has(key)) {
        typeMap.set(key, {
          batteryType: e.batteryType,
          specification: e.specification,
          brand: e.brand,
          colour: e.colour,
          totalQty: 0,
          locQty: {}
        });
      }
      const item = typeMap.get(key)!;
      const q = Number(e.qty) || 0;
      item.totalQty += q;
      item.locQty[e.locationId] = (item.locQty[e.locationId] || 0) + q;
    });

    const typeList = Array.from(typeMap.values()).sort((a, b) => b.totalQty - a.totalQty);

    return {
      totalRecords: entries.length,
      totalQty,
      locMap,
      statusMap,
      brandList,
      typeList
    };
  }, [entries, locations, masterData]);

  // Filtered rows for the consolidated view
  const displayEntries = useMemo(() => {
    if (selectedFilterLoc === 'ALL') return entries;
    return entries.filter(e => e.locationId === selectedFilterLoc);
  }, [entries, selectedFilterLoc]);

  // Handle file import from another device / location
  const handleImportMerge = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      if (file.name.endsWith('.json')) {
        const text = await file.text();
        const json = JSON.parse(text);
        const incomingEntries = Array.isArray(json) ? json : json.entries;
        if (!Array.isArray(incomingEntries)) {
          throw new Error('Invalid JSON format. Expected list of battery records.');
        }
        const result = StorageService.mergeExternalEntries(incomingEntries);
        onRefreshEntries();
        setImportStatus({
          message: `Successfully merged JSON file: ${result.added} new records added, ${result.updated} updated!`,
          type: 'success'
        });
      } else {
        // Excel or CSV file
        const parsed = await ExcelService.parseFile(
          file, 
          locations[0]?.id || 'loc-1', 
          locations[0]?.name || 'Imported Location'
        );
        const result = StorageService.mergeExternalEntries(parsed);
        onRefreshEntries();
        setImportStatus({
          message: `Successfully merged spreadsheet file: ${result.added} records imported!`,
          type: 'success'
        });
      }
    } catch (err: any) {
      setImportStatus({
        message: 'Failed to import file: ' + (err.message || 'Check file format.'),
        type: 'error'
      });
    }

    // Reset input
    e.target.value = '';
  };

  // Export full multi-tab compilation workbook
  const handleExportFullCompilation = () => {
    ExcelService.exportCompilationWorkbook(entries, locations);
  };

  // Copy all raw data as JSON for quick offline sharing (via WhatsApp, messaging, or email)
  const handleCopyJson = async () => {
    try {
      await navigator.clipboard.writeText(JSON.stringify(entries, null, 2));
      setCopiedJson(true);
      setTimeout(() => setCopiedJson(false), 2500);
    } catch {
      alert('Could not copy to clipboard.');
    }
  };

  const handleDownloadJsonBackup = () => {
    deliverFile({
      fileName: `battery_audit_compilation_${new Date().toISOString().slice(0, 10)}.json`,
      mimeType: 'application/json',
      text: JSON.stringify(entries, null, 2)
    }).catch(err => alert('Backup failed: ' + (err?.message || 'could not save file')));
  };

  return (
    <div className="space-y-5">
      
      {/* Compilation Overview Header */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/60 to-slate-900 border border-slate-700/80 rounded-3xl p-5 text-white shadow-xl">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="p-1.5 rounded-lg bg-indigo-600 text-white font-bold">
                <Building2 className="w-4 h-4" />
              </span>
              <h2 className="text-lg sm:text-xl font-extrabold text-white tracking-tight">
                Multi-Location Compilation Hub
              </h2>
            </div>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              Consolidates data collected from all 3 to 4 field locations (plants, warehouses, depots &amp; yards). Merge offline audit files or export combined multi-sheet Excel reports.
            </p>
          </div>

          {/* Compilation Export / Import Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Import / Merge External Audit Sheet */}
            <label className="bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold px-3.5 py-2.5 rounded-xl flex items-center gap-2 cursor-pointer shadow-sm transition-all active:scale-95">
              <Upload className="w-4 h-4 text-cyan-400" />
              <span>Merge Location File</span>
              <input
                type="file"
                accept=".xlsx,.xls,.csv,.json,application/json,text/csv,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/plain"
                onChange={handleImportMerge}
                className="hidden"
              />
            </label>

            {/* Export Multi-Sheet Excel Workbook */}
            <button
              type="button"
              onClick={handleExportFullCompilation}
              className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold px-4 py-2.5 rounded-xl flex items-center gap-2 shadow-lg shadow-emerald-600/20 active:scale-95 transition-all"
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span>Export Compiled Excel (.xlsx)</span>
            </button>

            {/* Backup JSON */}
            <button
              type="button"
              onClick={handleDownloadJsonBackup}
              className="bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs font-semibold px-3 py-2.5 rounded-xl flex items-center gap-1.5 transition-colors"
              title="Download raw JSON data backup"
            >
              <Download className="w-4 h-4" />
              <span>JSON</span>
            </button>
          </div>
        </div>

        {/* Import notification */}
        {importStatus && (
          <div className={`mt-3 p-3 rounded-xl text-xs flex items-center justify-between gap-2 ${
            importStatus.type === 'success' 
              ? 'bg-emerald-950/80 text-emerald-200 border border-emerald-800' 
              : 'bg-rose-950/80 text-rose-200 border border-rose-800'
          }`}>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{importStatus.message}</span>
            </div>
            <button 
              type="button" 
              onClick={() => setImportStatus(null)}
              className="font-bold underline text-[11px]"
            >
              Dismiss
            </button>
          </div>
        )}
      </div>

      {/* Location Comparison Cards (3 to 4 Locations) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {summary.locMap.map(loc => {
          const isSelected = selectedFilterLoc === loc.id;
          return (
            <div
              key={loc.id}
              onClick={() => setSelectedFilterLoc(isSelected ? 'ALL' : loc.id)}
              className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                isSelected 
                  ? 'bg-blue-950/40 border-blue-500 shadow-md shadow-blue-500/10 ring-2 ring-blue-500/30' 
                  : 'bg-slate-900 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 border border-slate-700">
                  {loc.code}
                </span>
                <span className="text-xs font-semibold text-slate-400">
                  {loc.city || 'Oman'}
                </span>
              </div>
              <h3 className="font-bold text-sm text-white line-clamp-1 mb-3">
                {loc.name}
              </h3>
              
              <div className="flex items-baseline justify-between pt-2 border-t border-slate-800">
                <div>
                  <span className="text-[10px] text-slate-400 block uppercase font-medium">Logged Qty</span>
                  <span className="text-xl font-mono font-black text-blue-300">
                    {loc.totalQty}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 block uppercase font-medium">Entries</span>
                  <span className="text-sm font-mono font-bold text-slate-200">
                    {loc.recordCount}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Aggregate Metric Highlights: Status & Brands */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        
        {/* Status Distribution (DRY, MF, WET, Under Charging) */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 text-white">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-sm text-slate-200 flex items-center gap-2">
              <PieChart className="w-4 h-4 text-blue-400" />
              Consolidated Status Breakdown
            </h3>
            <span className="text-xs text-slate-400 font-mono">
              Total {summary.totalQty} Batteries
            </span>
          </div>

          <div className="space-y-2.5">
            {summary.statusMap.map(st => {
              let barColor = 'bg-blue-600';
              if (st.status === 'MF') barColor = 'bg-emerald-500';
              else if (st.status === 'DRY') barColor = 'bg-blue-500';
              else if (st.status === 'WET') barColor = 'bg-cyan-500';
              else if (st.status === 'Under Charging') barColor = 'bg-amber-500';

              return (
                <div key={st.status} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-300">{st.status}</span>
                    <span className="font-mono text-slate-300 font-semibold">
                      {st.quantity} units ({st.percent}%)
                    </span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-2.5 overflow-hidden">
                    <div 
                      className={`h-full rounded-full transition-all duration-500 ${barColor}`} 
                      style={{ width: `${Math.max(st.percent, st.quantity > 0 ? 3 : 0)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Top Brands Breakdown */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 text-white">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-sm text-slate-200 flex items-center gap-2">
              <BarChart2 className="w-4 h-4 text-purple-400" />
              Top Brands Volume
            </h3>
            <span className="text-xs text-slate-400">
              {summary.brandList.length} Active Brands
            </span>
          </div>

          <div className="max-h-48 overflow-y-auto space-y-2 pr-1">
            {summary.brandList.map((item, idx) => {
              const pct = summary.totalQty > 0 ? Math.round((item.qty / summary.totalQty) * 100) : 0;
              return (
                <div key={item.brand} className="flex items-center justify-between text-xs p-1.5 rounded-lg hover:bg-slate-800/60">
                  <div className="flex items-center gap-2">
                    <span className="w-5 text-[11px] font-mono font-bold text-slate-400">
                      #{idx + 1}
                    </span>
                    <span className="font-semibold text-slate-200">{item.brand}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="font-mono font-bold text-blue-300">{item.qty} units</span>
                    <span className="text-[10px] text-slate-400 font-mono w-10 text-right">({pct}%)</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>

      {/* Cross-Location Pivot: Battery Type & Spec Totals */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl overflow-hidden">
        <div className="p-4 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="font-bold text-base text-white">
              Battery Type &amp; Spec Cross-Tabulation
            </h3>
            <p className="text-xs text-slate-400">
              Quantities broken down by Battery Type, Spec, Brand and Location
            </p>
          </div>

          {/* Location Filter Filter buttons */}
          <div className="flex items-center gap-1.5 overflow-x-auto py-1">
            <button
              type="button"
              onClick={() => setSelectedFilterLoc('ALL')}
              className={`px-2.5 py-1 text-xs font-bold rounded-lg transition-colors ${
                selectedFilterLoc === 'ALL' ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              All Locations
            </button>
            {locations.map(loc => (
              <button
                key={loc.id}
                type="button"
                onClick={() => setSelectedFilterLoc(loc.id)}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg transition-colors shrink-0 ${
                  selectedFilterLoc === loc.id ? 'bg-blue-600 text-white font-bold' : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {loc.code || loc.name.substring(0, 10)}
              </button>
            ))}
          </div>
        </div>

        {/* Pivot Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-850 text-slate-300 font-bold border-b border-slate-800 uppercase text-[11px] tracking-wider">
                <th className="py-3 px-3">Battery Type</th>
                <th className="py-3 px-3">Brand</th>
                <th className="py-3 px-3">Specification</th>
                <th className="py-3 px-3">Box Colour</th>
                <th className="py-3 px-3 text-center bg-blue-950/40 text-blue-300 font-black">
                  Total Qty
                </th>
                {locations.map(loc => (
                  <th key={loc.id} className="py-3 px-3 text-center">
                    {loc.code || loc.name.substring(0, 12)}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-200">
              {summary.typeList.map((row, idx) => (
                <tr key={`${row.batteryType}-${row.specification}-${row.brand}-${row.colour}-${idx}`} className="hover:bg-slate-800/60 transition-colors">
                  <td className="py-2.5 px-3 font-mono font-bold text-blue-300">
                    {row.batteryType}
                  </td>
                  <td className="py-2.5 px-3 font-semibold text-slate-200">
                    {row.brand}
                  </td>
                  <td className="py-2.5 px-3 text-cyan-300">
                    <span className="bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
                      {row.specification}
                    </span>
                  </td>
                  <td className="py-2.5 px-3">
                    <span className="text-slate-300">{row.colour}</span>
                  </td>
                  <td className="py-2.5 px-3 text-center font-mono font-black text-sm text-blue-300 bg-blue-950/20">
                    {row.totalQty}
                  </td>
                  {locations.map(loc => {
                    const count = row.locQty[loc.id] || 0;
                    return (
                      <td key={loc.id} className="py-2.5 px-3 text-center font-mono">
                        {count > 0 ? (
                          <span className="font-bold text-white">{count}</span>
                        ) : (
                          <span className="text-slate-600">—</span>
                        )}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Offline Sync & Data Transfer Utility */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 text-xs text-slate-300 space-y-2">
        <h4 className="font-bold text-sm text-white flex items-center gap-2">
          <Share2 className="w-4 h-4 text-cyan-400" />
          Field Data Compilation Instructions (Offline Environments)
        </h4>
        <p className="text-slate-400 leading-relaxed">
          When field auditors collect data at 3 to 4 remote locations without internet access, each auditor can use this app on their mobile or tablet. When ready to compile:
        </p>
        <ul className="list-disc pl-5 space-y-1 text-slate-300">
          <li>Auditors at Location A, B, C, D click <strong>Excel Export</strong> or <strong>JSON</strong> on their devices.</li>
          <li>Send the exported files via Bluetooth, local Wi-Fi, WhatsApp, or USB flash drive to the central tablet / computer.</li>
          <li>Click <strong>Merge Location File</strong> above to combine all records into one unified database with 1 click.</li>
        </ul>
      </div>

    </div>
  );
};
