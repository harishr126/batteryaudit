import React, { useState, useMemo } from 'react';
import { 
  Plus, Copy, Search, Filter, Download, Upload, Trash2, Edit3, 
  Layers, Palette, Tag, Barcode, Calendar, Hash, CheckSquare, 
  Square, FileSpreadsheet, Eye, EyeOff, PlusCircle, MinusCircle, 
  Sparkles, RefreshCw, Smartphone, Tablet
} from 'lucide-react';
import { BatteryEntry, MasterData, FilterState } from '../types/battery';
import { ExcelService } from '../services/excelService';

interface DataCollectionSheetProps {
  entries: BatteryEntry[];
  masterData: MasterData;
  activeLocationId: string;
  onAddEntry: () => void;
  onEditEntry: (entry: BatteryEntry) => void;
  onDuplicateEntry: (entry: BatteryEntry) => void;
  onDeleteEntry: (id: string) => void;
  onDeleteMultiple: (ids: string[]) => void;
  onUpdateQty: (id: string, delta: number) => void;
  onImportFile: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

export const DataCollectionSheet: React.FC<DataCollectionSheetProps> = ({
  entries,
  masterData,
  activeLocationId,
  onAddEntry,
  onEditEntry,
  onDuplicateEntry,
  onDeleteEntry,
  onDeleteMultiple,
  onUpdateQty,
  onImportFile
}) => {
  const [viewMode, setViewMode] = useState<'table' | 'cards'>('table');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBrand, setSelectedBrand] = useState('ALL');
  const [selectedSpec, setSelectedSpec] = useState('ALL');
  const [selectedStatus, setSelectedStatus] = useState('ALL');
  const [selectedColour, setSelectedColour] = useState('ALL');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [showFilters, setShowFilters] = useState(false);

  // Active location details
  const activeLoc = masterData.locations.find(l => l.id === activeLocationId) || masterData.locations[0];

  // Filter entries for active location & filter criteria
  const locationEntries = useMemo(() => {
    return entries.filter(e => e.locationId === activeLocationId);
  }, [entries, activeLocationId]);

  const filteredEntries = useMemo(() => {
    return locationEntries.filter(e => {
      // Search text
      if (searchTerm.trim()) {
        const term = searchTerm.toLowerCase().trim();
        const matches = 
          (e.batteryType && e.batteryType.toLowerCase().includes(term)) ||
          (e.brand && e.brand.toLowerCase().includes(term)) ||
          (e.specification && e.specification.toLowerCase().includes(term)) ||
          (e.productionCode && e.productionCode.toLowerCase().includes(term)) ||
          (e.remarks && e.remarks.toLowerCase().includes(term)) ||
          (e.monthOfCharge && e.monthOfCharge.toLowerCase().includes(term));
        if (!matches) return false;
      }

      if (selectedBrand !== 'ALL' && e.brand !== selectedBrand) return false;
      if (selectedSpec !== 'ALL' && e.specification !== selectedSpec) return false;
      if (selectedStatus !== 'ALL' && e.status !== selectedStatus) return false;
      if (selectedColour !== 'ALL' && e.colour !== selectedColour) return false;

      return true;
    });
  }, [locationEntries, searchTerm, selectedBrand, selectedSpec, selectedStatus, selectedColour]);

  // Statistics for this location
  const stats = useMemo(() => {
    const totalQty = filteredEntries.reduce((sum, e) => sum + (Number(e.qty) || 0), 0);
    const dryCount = filteredEntries.filter(e => e.status === 'DRY').reduce((sum, e) => sum + (Number(e.qty) || 0), 0);
    const mfCount = filteredEntries.filter(e => e.status === 'MF').reduce((sum, e) => sum + (Number(e.qty) || 0), 0);
    const wetCount = filteredEntries.filter(e => e.status === 'WET').reduce((sum, e) => sum + (Number(e.qty) || 0), 0);
    const chargingCount = filteredEntries.filter(e => e.status === 'Under Charging').reduce((sum, e) => sum + (Number(e.qty) || 0), 0);
    return { totalQty, dryCount, mfCount, wetCount, chargingCount };
  }, [filteredEntries]);

  // Bulk selection handlers
  const handleSelectAll = () => {
    if (selectedIds.length === filteredEntries.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredEntries.map(e => e.id));
    }
  };

  const handleToggleSelect = (id: string) => {
    setSelectedIds(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const handleBulkDelete = () => {
    if (window.confirm(`Delete ${selectedIds.length} selected entries?`)) {
      onDeleteMultiple(selectedIds);
      setSelectedIds([]);
    }
  };

  const handleExportExcel = () => {
    ExcelService.exportToExcel(
      filteredEntries, 
      `${activeLoc.name.substring(0, 20)} Battery Audit`
    );
  };

  const handleExportCSV = () => {
    ExcelService.exportToCSV(
      filteredEntries, 
      `${activeLoc.code || 'Location'}_Battery_Audit`
    );
  };

  const handleDuplicateLast = () => {
    if (filteredEntries.length > 0) {
      onDuplicateEntry(filteredEntries[filteredEntries.length - 1]);
    } else if (locationEntries.length > 0) {
      onDuplicateEntry(locationEntries[locationEntries.length - 1]);
    } else {
      onAddEntry();
    }
  };

  const getColourBadge = (colourName: string) => {
    const match = masterData.colours.find(c => c.name.toLowerCase() === colourName.toLowerCase());
    const hex = match ? match.hex : '#94a3b8';
    return (
      <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-xs font-semibold bg-slate-800 border border-slate-700">
        <span 
          className="w-2.5 h-2.5 rounded-full border border-black/40 shrink-0" 
          style={{ backgroundColor: hex }} 
        />
        <span>{colourName}</span>
      </span>
    );
  };

  const getStatusBadge = (statusName: string) => {
    let classes = 'bg-slate-800 text-slate-300 border-slate-700';
    if (statusName === 'MF') classes = 'bg-emerald-950/80 text-emerald-300 border-emerald-800';
    else if (statusName === 'DRY') classes = 'bg-blue-950/80 text-blue-300 border-blue-800';
    else if (statusName === 'WET') classes = 'bg-cyan-950/80 text-cyan-300 border-cyan-800';
    else if (statusName === 'Under Charging') classes = 'bg-amber-950/80 text-amber-300 border-amber-800';

    return (
      <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-xs font-bold border ${classes}`}>
        {statusName}
      </span>
    );
  };

  return (
    <div className="space-y-4">
      
      {/* Top Banner & Quick Metrics */}
      <div className="bg-slate-850 border border-slate-700/80 rounded-2xl p-4 text-white shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 text-xs font-extrabold rounded-md bg-blue-950 text-blue-300 border border-blue-800">
                {activeLoc.code || 'LOC-ACTIVE'}
              </span>
              <h2 className="text-base sm:text-lg font-bold text-white tracking-tight">
                {activeLoc.name}
              </h2>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Data collection sheet • {filteredEntries.length} items logged ({stats.totalQty} total quantity)
            </p>
          </div>

          {/* Quick Stats Chips */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="bg-slate-800/90 border border-slate-700 px-3 py-1.5 rounded-xl text-center">
              <span className="text-[10px] text-slate-400 block uppercase font-bold">Total Qty</span>
              <span className="text-sm font-mono font-black text-white">{stats.totalQty}</span>
            </div>
            <div className="bg-emerald-950/50 border border-emerald-800/60 px-3 py-1.5 rounded-xl text-center">
              <span className="text-[10px] text-emerald-400 block uppercase font-bold">MF</span>
              <span className="text-sm font-mono font-black text-emerald-300">{stats.mfCount}</span>
            </div>
            <div className="bg-blue-950/50 border border-blue-800/60 px-3 py-1.5 rounded-xl text-center">
              <span className="text-[10px] text-blue-400 block uppercase font-bold">DRY</span>
              <span className="text-sm font-mono font-black text-blue-300">{stats.dryCount}</span>
            </div>
            <div className="bg-cyan-950/50 border border-cyan-800/60 px-3 py-1.5 rounded-xl text-center">
              <span className="text-[10px] text-cyan-400 block uppercase font-bold">WET</span>
              <span className="text-sm font-mono font-black text-cyan-300">{stats.wetCount}</span>
            </div>
            <div className="bg-amber-950/50 border border-amber-800/60 px-3 py-1.5 rounded-xl text-center">
              <span className="text-[10px] text-amber-400 block uppercase font-bold">Charging</span>
              <span className="text-sm font-mono font-black text-amber-300">{stats.chargingCount}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Action Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-2.5">
        
        {/* Left: Primary Data Entry Buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={onAddEntry}
            className="bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs sm:text-sm px-4 py-2.5 rounded-xl flex items-center gap-2 shadow-lg shadow-blue-600/30 active:scale-95 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Add Battery Row</span>
          </button>

          <button
            type="button"
            onClick={handleDuplicateLast}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs sm:text-sm px-3.5 py-2.5 rounded-xl flex items-center gap-1.5 border border-slate-700 active:scale-95 transition-all"
            title="Duplicate the previous battery row to quickly log similar batch"
          >
            <Copy className="w-4 h-4 text-cyan-400" />
            <span className="hidden sm:inline">Duplicate Last</span>
            <span className="sm:hidden">Clone</span>
          </button>

          {/* Import Excel / CSV Button */}
          <label className="bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-semibold text-xs px-3 py-2.5 rounded-xl flex items-center gap-1.5 border border-slate-700 cursor-pointer transition-colors">
            <Upload className="w-4 h-4 text-indigo-400" />
            <span className="hidden sm:inline">Import Sheet</span>
            <input 
              type="file" 
              accept=".xlsx,.xls,.csv,text/csv,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/plain" 
              onChange={onImportFile} 
              className="hidden" 
            />
          </label>
        </div>

        {/* Right: Export & View toggles */}
        <div className="flex items-center gap-2 flex-wrap">
          {selectedIds.length > 0 && (
            <button
              type="button"
              onClick={handleBulkDelete}
              className="bg-rose-950/80 hover:bg-rose-900 text-rose-300 border border-rose-800 font-bold text-xs px-3 py-2.5 rounded-xl flex items-center gap-1.5 transition-colors"
            >
              <Trash2 className="w-4 h-4" />
              <span>Delete ({selectedIds.length})</span>
            </button>
          )}

          {/* Export to Excel */}
          <button
            type="button"
            onClick={handleExportExcel}
            className="bg-emerald-600/20 hover:bg-emerald-600 text-emerald-300 hover:text-white border border-emerald-500/40 font-bold text-xs px-3.5 py-2.5 rounded-xl flex items-center gap-1.5 transition-colors"
            title="Export this location's data to Excel (.xlsx)"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Excel Export</span>
          </button>

          {/* Export to CSV */}
          <button
            type="button"
            onClick={handleExportCSV}
            className="bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 font-bold text-xs px-3 py-2.5 rounded-xl flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-4 h-4" />
            <span className="hidden sm:inline">CSV</span>
          </button>

          {/* View Mode Toggle (Table / Card) */}
          <div className="bg-slate-800 border border-slate-700 rounded-xl p-1 flex items-center">
            <button
              type="button"
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded-lg text-xs font-bold transition-all ${
                viewMode === 'table' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
              title="Table View (Tablet / Desktop)"
            >
              <Tablet className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setViewMode('cards')}
              className={`p-1.5 rounded-lg text-xs font-bold transition-all ${
                viewMode === 'cards' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
              title="Card View (Mobile Phone)"
            >
              <Smartphone className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Search and Filters Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 space-y-2.5">
        <div className="flex flex-col sm:flex-row items-center gap-2">
          {/* Search box */}
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search Battery Type (N50, NS40...), Brand, Spec, Prod Code..."
              className="w-full bg-slate-800/90 border border-slate-700/80 rounded-xl pl-9 pr-3 py-2 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
          </div>

          {/* Toggle advanced filter button */}
          <button
            type="button"
            onClick={() => setShowFilters(!showFilters)}
            className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 border transition-colors shrink-0 ${
              showFilters || selectedBrand !== 'ALL' || selectedSpec !== 'ALL' || selectedStatus !== 'ALL' || selectedColour !== 'ALL'
                ? 'bg-blue-600/20 text-blue-300 border-blue-500/50'
                : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-750'
            }`}
          >
            <Filter className="w-4 h-4" />
            <span>Filters</span>
            {(selectedBrand !== 'ALL' || selectedSpec !== 'ALL' || selectedStatus !== 'ALL' || selectedColour !== 'ALL') && (
              <span className="w-2 h-2 rounded-full bg-blue-400" />
            )}
          </button>

          {(searchTerm || selectedBrand !== 'ALL' || selectedSpec !== 'ALL' || selectedStatus !== 'ALL' || selectedColour !== 'ALL') && (
            <button
              type="button"
              onClick={() => {
                setSearchTerm('');
                setSelectedBrand('ALL');
                setSelectedSpec('ALL');
                setSelectedStatus('ALL');
                setSelectedColour('ALL');
              }}
              className="px-2.5 py-2 text-xs text-slate-400 hover:text-white transition-colors"
            >
              Reset
            </button>
          )}
        </div>

        {/* Collapsible Filter Dropdowns */}
        {showFilters && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-slate-800">
            <div>
              <label className="text-[11px] font-bold text-slate-400 block mb-1">Brand</label>
              <select
                value={selectedBrand}
                onChange={(e) => setSelectedBrand(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
              >
                <option value="ALL">All Brands ({masterData.brands.length})</option>
                {masterData.brands.map(b => (
                  <option key={b} value={b}>{b}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-400 block mb-1">Specification</label>
              <select
                value={selectedSpec}
                onChange={(e) => setSelectedSpec(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
              >
                <option value="ALL">All Specs ({masterData.specifications.length})</option>
                {masterData.specifications.map(s => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-400 block mb-1">Status</label>
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
              >
                <option value="ALL">All Statuses ({masterData.statuses.length})</option>
                {masterData.statuses.map(st => (
                  <option key={st} value={st}>{st}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[11px] font-bold text-slate-400 block mb-1">Box Colour</label>
              <select
                value={selectedColour}
                onChange={(e) => setSelectedColour(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500"
              >
                <option value="ALL">All Colours ({masterData.colours.length})</option>
                {masterData.colours.map(c => (
                  <option key={c.name} value={c.name}>{c.name}</option>
                ))}
              </select>
            </div>
          </div>
        )}
      </div>

      {/* Main Data Presentation */}
      {filteredEntries.length === 0 ? (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 sm:p-12 text-center text-slate-400">
          <Layers className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-200 mb-1">No Battery Records Found</h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto mb-4">
            No entries logged yet for {activeLoc.name} matching your search/filters. Start collecting data by tapping Add Battery Row.
          </p>
          <button
            type="button"
            onClick={onAddEntry}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-blue-600/30 inline-flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" /> Add First Entry
          </button>
        </div>
      ) : viewMode === 'table' ? (
        /* TABLE VIEW (Tablet & Desktop Optimized) with exact 10 columns */
        <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              {/* Header with requested 10 fields */}
              <thead>
                <tr className="bg-slate-800 text-slate-300 font-bold border-b border-slate-700/80 uppercase text-[11px] tracking-wider select-none">
                  <th className="py-3 px-3 w-10 text-center">
                    <button
                      type="button"
                      onClick={handleSelectAll}
                      className="text-slate-400 hover:text-white"
                      title="Select All"
                    >
                      {selectedIds.length === filteredEntries.length ? (
                        <CheckSquare className="w-4 h-4 text-blue-400" />
                      ) : (
                        <Square className="w-4 h-4" />
                      )}
                    </button>
                  </th>
                  <th className="py-3 px-2 text-center w-14">Sr no</th>
                  <th className="py-3 px-3">Battery Type</th>
                  <th className="py-3 px-3">Brand</th>
                  <th className="py-3 px-3">Specification</th>
                  <th className="py-3 px-3 text-center">Qty no's</th>
                  <th className="py-3 px-3">Status</th>
                  <th className="py-3 px-3">Colour</th>
                  <th className="py-3 px-3">production code</th>
                  <th className="py-3 px-3">Month of charge</th>
                  <th className="py-3 px-3">Remarks</th>
                  <th className="py-3 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 text-slate-200">
                {filteredEntries.map((item, index) => {
                  const isSelected = selectedIds.includes(item.id);
                  return (
                    <tr 
                      key={item.id} 
                      className={`hover:bg-slate-800/60 transition-colors ${
                        isSelected ? 'bg-blue-950/30' : ''
                      }`}
                    >
                      {/* Checkbox */}
                      <td className="py-2.5 px-3 text-center">
                        <button
                          type="button"
                          onClick={() => handleToggleSelect(item.id)}
                          className="text-slate-400 hover:text-white"
                        >
                          {isSelected ? (
                            <CheckSquare className="w-4 h-4 text-blue-400" />
                          ) : (
                            <Square className="w-4 h-4" />
                          )}
                        </button>
                      </td>

                      {/* 1. Sr no */}
                      <td className="py-2.5 px-2 text-center font-mono font-bold text-slate-400">
                        {item.srNo || (index + 1)}
                      </td>

                      {/* 2. Battery Type */}
                      <td className="py-2.5 px-3 font-mono font-bold text-blue-300 whitespace-nowrap">
                        {item.batteryType}
                      </td>

                      {/* 3. Brand */}
                      <td className="py-2.5 px-3 font-semibold text-slate-100 whitespace-nowrap">
                        {item.brand}
                      </td>

                      {/* 4. Specification */}
                      <td className="py-2.5 px-3 font-medium text-cyan-300 whitespace-nowrap">
                        <span className="bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
                          {item.specification}
                        </span>
                      </td>

                      {/* 5. Qty no's with inline quick stepper */}
                      <td className="py-2.5 px-3 text-center whitespace-nowrap">
                        <div className="inline-flex items-center gap-1.5 bg-slate-800/80 px-2 py-1 rounded-lg border border-slate-700">
                          <button
                            type="button"
                            onClick={() => onUpdateQty(item.id, -1)}
                            className="text-slate-400 hover:text-white active:scale-90"
                            title="Decrease Qty"
                          >
                            <MinusCircle className="w-3.5 h-3.5" />
                          </button>
                          <span className="font-mono font-black text-sm text-white min-w-[24px]">
                            {item.qty}
                          </span>
                          <button
                            type="button"
                            onClick={() => onUpdateQty(item.id, 1)}
                            className="text-blue-400 hover:text-blue-300 active:scale-90"
                            title="Increase Qty"
                          >
                            <PlusCircle className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>

                      {/* 6. Status */}
                      <td className="py-2.5 px-3 whitespace-nowrap">
                        {getStatusBadge(item.status)}
                      </td>

                      {/* 7. Colour */}
                      <td className="py-2.5 px-3 whitespace-nowrap">
                        {getColourBadge(item.colour)}
                      </td>

                      {/* 8. production code */}
                      <td className="py-2.5 px-3 font-mono text-xs text-amber-300 font-semibold whitespace-nowrap">
                        {item.productionCode || <span className="text-slate-600 italic">—</span>}
                      </td>

                      {/* 9. Month of charge */}
                      <td className="py-2.5 px-3 font-mono font-bold text-emerald-400 whitespace-nowrap">
                        {item.monthOfCharge || '—'}
                      </td>

                      {/* 10. Remarks */}
                      <td className="py-2.5 px-3 text-slate-300 max-w-[200px] truncate" title={item.remarks}>
                        {item.remarks || <span className="text-slate-600 italic">—</span>}
                      </td>

                      {/* Actions */}
                      <td className="py-2.5 px-3 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1">
                          <button
                            type="button"
                            onClick={() => onDuplicateEntry(item)}
                            className="p-1.5 text-slate-400 hover:text-cyan-400 hover:bg-slate-800 rounded-lg transition-colors"
                            title="Duplicate Entry"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => onEditEntry(item)}
                            className="p-1.5 text-slate-400 hover:text-blue-400 hover:bg-slate-800 rounded-lg transition-colors"
                            title="Edit Entry"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              if (window.confirm('Delete this battery entry?')) {
                                onDeleteEntry(item.id);
                              }
                            }}
                            className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition-colors"
                            title="Delete Entry"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* MOBILE CARD VIEW (Optimized for Handheld Mobile Phones on Floor) */
        <div className="grid grid-cols-1 gap-3">
          {filteredEntries.map((item, index) => {
            const isSelected = selectedIds.includes(item.id);
            return (
              <div
                key={item.id}
                className={`bg-slate-900 border rounded-2xl p-4 space-y-3 transition-all ${
                  isSelected ? 'border-blue-500 bg-blue-950/20' : 'border-slate-800'
                }`}
              >
                {/* Card Top: Sr No, Battery Type, Qty */}
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="w-7 h-7 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center font-mono font-bold text-xs text-slate-300">
                      #{item.srNo || index + 1}
                    </span>
                    <div>
                      <h4 className="font-mono font-black text-sm text-blue-300 tracking-wide">
                        {item.batteryType}
                      </h4>
                      <p className="text-xs font-semibold text-slate-200">
                        {item.brand}
                      </p>
                    </div>
                  </div>

                  {/* Quantity Stepper */}
                  <div className="flex items-center gap-1.5 bg-slate-800 px-2 py-1 rounded-xl border border-slate-700">
                    <button
                      type="button"
                      onClick={() => onUpdateQty(item.id, -1)}
                      className="p-1 text-slate-400 hover:text-white"
                    >
                      <MinusCircle className="w-4 h-4" />
                    </button>
                    <span className="font-mono font-black text-sm text-white px-1">
                      {item.qty}
                    </span>
                    <button
                      type="button"
                      onClick={() => onUpdateQty(item.id, 1)}
                      className="p-1 text-blue-400 hover:text-blue-300"
                    >
                      <PlusCircle className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Card Middle: Badges for Spec, Status, Colour, Month */}
                <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-slate-800/80">
                  <span className="text-xs bg-slate-800 text-cyan-300 px-2 py-0.5 rounded-md border border-slate-700 font-medium">
                    Spec: {item.specification}
                  </span>
                  {getStatusBadge(item.status)}
                  {getColourBadge(item.colour)}
                  <span className="text-xs font-mono font-bold text-emerald-400 bg-slate-800 px-2 py-0.5 rounded-md border border-slate-700">
                    Chg: {item.monthOfCharge}
                  </span>
                </div>

                {/* Card Bottom: Production Code & Remarks */}
                {(item.productionCode || item.remarks) && (
                  <div className="bg-slate-850 p-2.5 rounded-xl border border-slate-800 text-xs space-y-1">
                    {item.productionCode && (
                      <div className="flex items-center gap-1 font-mono text-amber-300">
                        <Barcode className="w-3.5 h-3.5 text-slate-400" />
                        <span>Code: {item.productionCode}</span>
                      </div>
                    )}
                    {item.remarks && (
                      <p className="text-slate-300 italic">
                        "{item.remarks}"
                      </p>
                    )}
                  </div>
                )}

                {/* Card Actions */}
                <div className="flex items-center justify-between pt-1 border-t border-slate-800">
                  <button
                    type="button"
                    onClick={() => handleToggleSelect(item.id)}
                    className="text-xs text-slate-400 flex items-center gap-1.5"
                  >
                    {isSelected ? (
                      <CheckSquare className="w-4 h-4 text-blue-400" />
                    ) : (
                      <Square className="w-4 h-4" />
                    )}
                    <span>Select</span>
                  </button>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => onDuplicateEntry(item)}
                      className="px-2.5 py-1 text-xs bg-slate-800 hover:bg-slate-750 text-slate-200 rounded-lg flex items-center gap-1 border border-slate-700"
                    >
                      <Copy className="w-3 h-3 text-cyan-400" /> Duplicate
                    </button>
                    <button
                      type="button"
                      onClick={() => onEditEntry(item)}
                      className="px-2.5 py-1 text-xs bg-blue-600/30 hover:bg-blue-600 text-blue-300 hover:text-white rounded-lg flex items-center gap-1 border border-blue-500/40"
                    >
                      <Edit3 className="w-3 h-3" /> Edit
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (window.confirm('Delete this entry?')) onDeleteEntry(item.id);
                      }}
                      className="p-1.5 text-slate-400 hover:text-rose-400"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Footer Info */}
      <div className="flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 py-2 border-t border-slate-800/80 gap-2">
        <div>
          Showing {filteredEntries.length} of {locationEntries.length} records in {activeLoc.name}
        </div>
        <div className="flex items-center gap-3">
          <span>All data automatically saved locally (Offline Ready)</span>
        </div>
      </div>
    </div>
  );
};
