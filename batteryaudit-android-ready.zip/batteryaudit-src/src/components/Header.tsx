import React, { useState } from 'react';
import { 
  ClipboardList, BarChart3, Settings, MapPin, Wifi, WifiOff, 
  User, ChevronDown, Check, Battery, Sparkles, PlusCircle 
} from 'lucide-react';
import { LocationInfo } from '../types/battery';

interface HeaderProps {
  activeTab: 'sheet' | 'compilation' | 'masters';
  setActiveTab: (tab: 'sheet' | 'compilation' | 'masters') => void;
  locations: LocationInfo[];
  activeLocationId: string;
  onSelectLocation: (id: string) => void;
  auditorName: string;
  onUpdateAuditorName: (name: string) => void;
  totalEntriesCount: number;
  currentLocCount: number;
  onQuickAdd: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  locations,
  activeLocationId,
  onSelectLocation,
  auditorName,
  onUpdateAuditorName,
  totalEntriesCount,
  currentLocCount,
  onQuickAdd
}) => {
  const [isLocDropdownOpen, setIsLocDropdownOpen] = useState(false);
  const [isAuditorPromptOpen, setIsAuditorPromptOpen] = useState(false);
  const [tempAuditorName, setTempAuditorName] = useState(auditorName);
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  React.useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const activeLoc = locations.find(l => l.id === activeLocationId) || locations[0];

  const handleSaveAuditor = (e: React.FormEvent) => {
    e.preventDefault();
    if (tempAuditorName.trim()) {
      onUpdateAuditorName(tempAuditorName.trim());
      setIsAuditorPromptOpen(false);
    }
  };

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-30 shadow-md safe-area-pt">
      {/* Top Banner Bar */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2.5 flex flex-wrap items-center justify-between gap-2">
        {/* Brand & Title */}
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-cyan-400 flex items-center justify-center shadow-lg shadow-blue-500/20 text-white font-black">
            <Battery className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-extrabold text-sm sm:text-base tracking-tight text-white">
                BatteryAudit <span className="text-blue-400">Pro</span>
              </h1>
              {/* Offline Badge */}
              <span className={`inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-full border ${
                isOnline 
                  ? 'bg-emerald-950/80 text-emerald-300 border-emerald-800/80' 
                  : 'bg-amber-950/80 text-amber-300 border-amber-800/80'
              }`}>
                {isOnline ? <Wifi className="w-3 h-3 text-emerald-400" /> : <WifiOff className="w-3 h-3 text-amber-400" />}
                {isOnline ? 'Online / Synced' : 'Offline Mode (Local Storage)'}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 hidden sm:block">
              Multi-Location Battery Inventory &amp; Spec Collection
            </p>
          </div>
        </div>

        {/* Right side controls: Location Selector & Auditor Badge */}
        <div className="flex items-center gap-2">
          {/* Active Location Dropdown Pill */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setIsLocDropdownOpen(!isLocDropdownOpen)}
              className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs font-bold transition-all shadow-xs"
            >
              <MapPin className="w-3.5 h-3.5 text-blue-400 shrink-0" />
              <span className="max-w-[130px] sm:max-w-[180px] truncate">{activeLoc?.name}</span>
              <span className="text-[10px] bg-blue-900 text-blue-300 px-1.5 py-0.5 rounded-md font-mono">
                {currentLocCount}
              </span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {isLocDropdownOpen && (
              <div className="absolute right-0 mt-1.5 w-64 bg-slate-800 border border-slate-700 rounded-2xl shadow-xl z-50 p-2 text-xs">
                <div className="px-2 py-1 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                  Select Audit Location (3-4 sites)
                </div>
                <div className="space-y-1 mt-1">
                  {locations.map(loc => {
                    const isSelected = loc.id === activeLocationId;
                    return (
                      <button
                        key={loc.id}
                        type="button"
                        onClick={() => {
                          onSelectLocation(loc.id);
                          setIsLocDropdownOpen(false);
                        }}
                        className={`w-full text-left px-2.5 py-2 rounded-xl flex items-center justify-between transition-colors ${
                          isSelected ? 'bg-blue-600 text-white font-bold' : 'text-slate-300 hover:bg-slate-700'
                        }`}
                      >
                        <div className="truncate pr-2">
                          <div>{loc.name}</div>
                          <div className="text-[10px] opacity-75">{loc.city || loc.code}</div>
                        </div>
                        {isSelected && <Check className="w-4 h-4 shrink-0" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* Quick Inspector / Auditor tag */}
          <button
            type="button"
            onClick={() => {
              setTempAuditorName(auditorName);
              setIsAuditorPromptOpen(true);
            }}
            className="hidden md:flex items-center gap-1.5 bg-slate-800 hover:bg-slate-750 text-slate-300 border border-slate-750 rounded-xl px-2.5 py-1.5 text-xs font-semibold transition-colors"
            title="Edit Auditor Name"
          >
            <User className="w-3.5 h-3.5 text-slate-400" />
            <span className="max-w-[90px] truncate">{auditorName}</span>
          </button>

          {/* Quick Add Button */}
          <button
            type="button"
            onClick={onQuickAdd}
            className="bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs px-3 py-1.5 rounded-xl flex items-center gap-1.5 shadow-md shadow-blue-600/30 active:scale-95 transition-all"
          >
            <PlusCircle className="w-4 h-4" />
            <span className="hidden sm:inline">Add Battery</span>
          </button>
        </div>
      </div>

      {/* Main Tab Navigation Bar */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 flex items-center border-t border-slate-800/80">
        <nav className="flex space-x-1 sm:space-x-3 overflow-x-auto py-2">
          {/* Tab 1: Sheet View */}
          <button
            type="button"
            onClick={() => setActiveTab('sheet')}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs sm:text-sm font-bold rounded-xl transition-all shrink-0 ${
              activeTab === 'sheet'
                ? 'bg-blue-600/20 text-blue-400 border border-blue-500/40 shadow-xs'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <ClipboardList className="w-4 h-4" />
            <span>Data Collection Sheet</span>
            <span className="bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded-md text-[10px] font-mono">
              {currentLocCount}
            </span>
          </button>

          {/* Tab 2: Multi-Location Compilation */}
          <button
            type="button"
            onClick={() => setActiveTab('compilation')}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs sm:text-sm font-bold rounded-xl transition-all shrink-0 ${
              activeTab === 'compilation'
                ? 'bg-blue-600/20 text-blue-400 border border-blue-500/40 shadow-xs'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            <span>Multi-Location Compilation</span>
            <span className="bg-indigo-900 text-indigo-300 px-1.5 py-0.5 rounded-md text-[10px] font-mono font-bold">
              {totalEntriesCount} Total
            </span>
          </button>

          {/* Tab 3: Master Catalog & Settings */}
          <button
            type="button"
            onClick={() => setActiveTab('masters')}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs sm:text-sm font-bold rounded-xl transition-all shrink-0 ${
              activeTab === 'masters'
                ? 'bg-blue-600/20 text-blue-400 border border-blue-500/40 shadow-xs'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>Master Catalog &amp; Lists</span>
          </button>
        </nav>
      </div>

      {/* Auditor Name Edit Modal */}
      {isAuditorPromptOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-2xl p-4 text-white shadow-2xl">
            <h3 className="font-bold text-sm mb-2 flex items-center gap-2">
              <User className="w-4 h-4 text-blue-400" />
              Inspector / Auditor Identification
            </h3>
            <p className="text-xs text-slate-400 mb-3">
              Tag new entries with this auditor name for audit trails.
            </p>
            <form onSubmit={handleSaveAuditor}>
              <input
                type="text"
                value={tempAuditorName}
                onChange={(e) => setTempAuditorName(e.target.value)}
                placeholder="e.g. Harish R."
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white mb-3 focus:outline-none focus:border-blue-500"
                autoFocus
              />
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAuditorPromptOpen(false)}
                  className="px-3 py-1.5 text-xs font-semibold text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-blue-600 text-white rounded-xl text-xs font-bold"
                >
                  Save Name
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </header>
  );
};
