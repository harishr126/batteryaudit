import React, { useState } from 'react';
import { 
  Plus, Trash2, Edit2, Check, X, Search, RotateCcw, 
  Tag, Sparkles, Layers, BatteryCharging, Palette, MapPin, 
  CheckCircle2, ArrowRight 
} from 'lucide-react';
import { MasterData, BoxColour, LocationInfo } from '../types/battery';
import { INITIAL_MASTER_DATA } from '../data/defaultMasters';

interface MasterDataManagerProps {
  masterData: MasterData;
  onUpdateMasterData: (data: MasterData) => void;
}

export const MasterDataManager: React.FC<MasterDataManagerProps> = ({
  masterData,
  onUpdateMasterData
}) => {
  const [activeCategory, setActiveCategory] = useState<'types' | 'brands' | 'specs' | 'statuses' | 'colours' | 'locations'>('types');
  const [searchTerm, setSearchTerm] = useState('');
  
  // New item inputs
  const [newTypeName, setNewTypeName] = useState('');
  const [newBrandName, setNewBrandName] = useState('');
  const [newSpecName, setNewSpecName] = useState('');
  const [newStatusName, setNewStatusName] = useState('');
  const [newColourName, setNewColourName] = useState('');
  const [newColourHex, setNewColourHex] = useState('#3b82f6');
  const [newLocName, setNewLocName] = useState('');
  const [newLocCode, setNewLocCode] = useState('');
  const [newLocCity, setNewLocCity] = useState('');

  // Bulk add modal for battery types
  const [bulkText, setBulkText] = useState('');
  const [showBulkAdd, setShowBulkAdd] = useState(false);

  // Success message
  const [bannerMsg, setBannerMsg] = useState<string | null>(null);

  const showNotification = (msg: string) => {
    setBannerMsg(msg);
    setTimeout(() => setBannerMsg(null), 3000);
  };

  // Battery Type handlers
  const handleAddBatteryType = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newTypeName.trim().toUpperCase();
    if (!trimmed) return;
    if (masterData.batteryTypes.includes(trimmed)) {
      alert('This battery type already exists in catalog.');
      return;
    }
    const updated = {
      ...masterData,
      batteryTypes: [trimmed, ...masterData.batteryTypes]
    };
    onUpdateMasterData(updated);
    setNewTypeName('');
    showNotification(`Added "${trimmed}" to Battery Types`);
  };

  const handleBulkAddTypes = () => {
    const lines = bulkText.split('\n').map(l => l.trim().toUpperCase()).filter(Boolean);
    if (lines.length === 0) return;
    const existing = new Set(masterData.batteryTypes);
    const toAdd = lines.filter(l => !existing.has(l));
    const updated = {
      ...masterData,
      batteryTypes: [...masterData.batteryTypes, ...toAdd]
    };
    onUpdateMasterData(updated);
    setBulkText('');
    setShowBulkAdd(false);
    showNotification(`Added ${toAdd.length} new battery types in bulk!`);
  };

  const handleDeleteType = (item: string) => {
    if (window.confirm(`Delete battery type "${item}"?`)) {
      onUpdateMasterData({
        ...masterData,
        batteryTypes: masterData.batteryTypes.filter(t => t !== item)
      });
      showNotification(`Deleted "${item}"`);
    }
  };

  // Brand handlers
  const handleAddBrand = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newBrandName.trim().toUpperCase();
    if (!trimmed) return;
    if (masterData.brands.includes(trimmed)) {
      alert('This brand already exists.');
      return;
    }
    onUpdateMasterData({
      ...masterData,
      brands: [...masterData.brands, trimmed]
    });
    setNewBrandName('');
    showNotification(`Added brand "${trimmed}"`);
  };

  const handleDeleteBrand = (b: string) => {
    if (window.confirm(`Delete brand "${b}"?`)) {
      onUpdateMasterData({
        ...masterData,
        brands: masterData.brands.filter(x => x !== b)
      });
    }
  };

  // Spec handlers
  const handleAddSpec = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newSpecName.trim().toUpperCase();
    if (!trimmed) return;
    if (masterData.specifications.includes(trimmed)) {
      alert('This specification already exists.');
      return;
    }
    onUpdateMasterData({
      ...masterData,
      specifications: [...masterData.specifications, trimmed]
    });
    setNewSpecName('');
    showNotification(`Added specification "${trimmed}"`);
  };

  const handleDeleteSpec = (s: string) => {
    if (window.confirm(`Delete specification "${s}"?`)) {
      onUpdateMasterData({
        ...masterData,
        specifications: masterData.specifications.filter(x => x !== s)
      });
    }
  };

  // Status handlers
  const handleAddStatus = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newStatusName.trim();
    if (!trimmed) return;
    if (masterData.statuses.includes(trimmed)) return;
    onUpdateMasterData({
      ...masterData,
      statuses: [...masterData.statuses, trimmed]
    });
    setNewStatusName('');
  };

  const handleDeleteStatus = (st: string) => {
    if (window.confirm(`Delete status "${st}"?`)) {
      onUpdateMasterData({
        ...masterData,
        statuses: masterData.statuses.filter(x => x !== st)
      });
    }
  };

  // Colour handlers
  const handleAddColour = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newColourName.trim();
    if (!trimmed) return;
    const exists = masterData.colours.some(c => c.name.toLowerCase() === trimmed.toLowerCase());
    if (exists) return;
    onUpdateMasterData({
      ...masterData,
      colours: [...masterData.colours, { name: trimmed, hex: newColourHex }]
    });
    setNewColourName('');
  };

  const handleDeleteColour = (colName: string) => {
    if (window.confirm(`Delete colour "${colName}"?`)) {
      onUpdateMasterData({
        ...masterData,
        colours: masterData.colours.filter(c => c.name !== colName)
      });
    }
  };

  // Location handlers
  const handleAddLocation = (e: React.FormEvent) => {
    e.preventDefault();
    const name = newLocName.trim();
    if (!name) return;
    const newLoc: LocationInfo = {
      id: 'loc-' + Date.now(),
      name,
      code: newLocCode.trim().toUpperCase() || `LOC-${masterData.locations.length + 1}`,
      city: newLocCity.trim() || 'Oman'
    };
    onUpdateMasterData({
      ...masterData,
      locations: [...masterData.locations, newLoc]
    });
    setNewLocName('');
    setNewLocCode('');
    setNewLocCity('');
    showNotification(`Added new location "${name}"`);
  };

  const handleDeleteLocation = (id: string) => {
    if (masterData.locations.length <= 1) {
      alert('You must have at least one active location.');
      return;
    }
    if (window.confirm('Delete this location?')) {
      onUpdateMasterData({
        ...masterData,
        locations: masterData.locations.filter(l => l.id !== id)
      });
    }
  };

  // Reset to default
  const handleResetToDefaults = () => {
    if (window.confirm('Reset all catalog dropdown lists to the original 100+ types, 20 brands, 10 specs, 4 statuses, and 6 colours?')) {
      onUpdateMasterData(INITIAL_MASTER_DATA);
      showNotification('Catalog lists restored to official defaults!');
    }
  };

  // Filtered types
  const filteredTypes = masterData.batteryTypes.filter(t => 
    t.toLowerCase().includes(searchTerm.toLowerCase().trim())
  );

  return (
    <div className="space-y-4">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-white">
        <div>
          <h2 className="text-base sm:text-lg font-bold text-white tracking-tight flex items-center gap-2">
            <Tag className="w-5 h-5 text-blue-400" />
            Master Catalog &amp; Dropdown Lists Manager
          </h2>
          <p className="text-xs text-slate-400">
            Customize battery types (100+ types), brands, specifications, box colours, and locations.
          </p>
        </div>

        <button
          type="button"
          onClick={handleResetToDefaults}
          className="bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 text-xs font-semibold px-3 py-2 rounded-xl flex items-center gap-1.5 transition-colors self-start sm:self-auto"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Restore Official Defaults</span>
        </button>
      </div>

      {bannerMsg && (
        <div className="p-3 bg-emerald-950/80 border border-emerald-800 text-emerald-300 rounded-xl text-xs flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4" />
          <span>{bannerMsg}</span>
        </div>
      )}

      {/* Category Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
        {[
          { id: 'types', label: `Battery Types (${masterData.batteryTypes.length})`, icon: Tag },
          { id: 'brands', label: `Brands (${masterData.brands.length})`, icon: Sparkles },
          { id: 'specs', label: `Specs (${masterData.specifications.length})`, icon: Layers },
          { id: 'statuses', label: `Status (${masterData.statuses.length})`, icon: BatteryCharging },
          { id: 'colours', label: `Colours (${masterData.colours.length})`, icon: Palette },
          { id: 'locations', label: `Locations (${masterData.locations.length})`, icon: MapPin }
        ].map(cat => {
          const Icon = cat.icon;
          const isSelected = activeCategory === cat.id;
          return (
            <button
              key={cat.id}
              type="button"
              onClick={() => setActiveCategory(cat.id as any)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all shrink-0 ${
                isSelected 
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30' 
                  : 'bg-slate-800/80 text-slate-400 hover:text-slate-200 hover:bg-slate-800 border border-slate-700/60'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{cat.label}</span>
            </button>
          );
        })}
      </div>

      {/* 1. BATTERY TYPES MANAGER */}
      {activeCategory === 'types' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            <form onSubmit={handleAddBatteryType} className="flex-1 w-full flex gap-2">
              <input
                type="text"
                placeholder="Add new battery type e.g. N50 MF HD, 58043DG MF..."
                value={newTypeName}
                onChange={(e) => setNewTypeName(e.target.value)}
                className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 uppercase"
              />
              <button
                type="submit"
                disabled={!newTypeName.trim()}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-bold text-xs rounded-xl flex items-center gap-1 shrink-0"
              >
                <Plus className="w-4 h-4" /> Add
              </button>
            </form>

            <button
              type="button"
              onClick={() => setShowBulkAdd(!showBulkAdd)}
              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 rounded-xl text-xs font-semibold shrink-0"
            >
              Bulk Add Types
            </button>
          </div>

          {showBulkAdd && (
            <div className="p-3 bg-slate-850 border border-slate-700 rounded-xl space-y-2">
              <label className="text-xs text-slate-300 font-semibold block">
                Paste battery types (one per line):
              </label>
              <textarea
                rows={4}
                value={bulkText}
                onChange={(e) => setBulkText(e.target.value)}
                placeholder="12N24-3 MF&#10;NS40 MF&#10;N50 MF..."
                className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-xs font-mono text-white focus:outline-none focus:border-blue-500"
              />
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowBulkAdd(false)}
                  className="px-3 py-1.5 text-xs text-slate-400"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleBulkAddTypes}
                  className="px-4 py-1.5 bg-blue-600 text-white font-bold text-xs rounded-xl"
                >
                  Import All
                </button>
              </div>
            </div>
          )}

          {/* Search filter for types */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
            <input
              type="text"
              placeholder={`Search among ${masterData.batteryTypes.length} battery types...`}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 font-mono"
            />
          </div>

          {/* Battery Types Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 max-h-96 overflow-y-auto pr-1">
            {filteredTypes.map((type, idx) => (
              <div
                key={type}
                className="flex items-center justify-between p-2 rounded-xl bg-slate-800 border border-slate-700/80 text-xs hover:border-slate-600 transition-colors"
              >
                <div className="flex items-center gap-1.5 truncate pr-1">
                  <span className="text-[10px] text-slate-400 font-mono">#{idx + 1}</span>
                  <span className="font-mono font-bold text-blue-300 truncate">{type}</span>
                </div>
                <button
                  type="button"
                  onClick={() => handleDeleteType(type)}
                  className="p-1 text-slate-400 hover:text-rose-400 shrink-0"
                  title="Delete type"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 2. BRANDS MANAGER (20 Brands) */}
      {activeCategory === 'brands' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-4">
          <form onSubmit={handleAddBrand} className="flex gap-2">
            <input
              type="text"
              placeholder="Add new brand name e.g. GULF POWER, ROYAL BATTERY..."
              value={newBrandName}
              onChange={(e) => setNewBrandName(e.target.value)}
              className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white uppercase placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
            <button
              type="submit"
              disabled={!newBrandName.trim()}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-bold text-xs rounded-xl flex items-center gap-1 shrink-0"
            >
              <Plus className="w-4 h-4" /> Add Brand
            </button>
          </form>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
            {masterData.brands.map((b, idx) => (
              <div
                key={b}
                className="flex items-center justify-between p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs"
              >
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-slate-400 font-mono">#{idx + 1}</span>
                  <span className="font-bold text-slate-100">{b}</span>
                </div>
                <button
                  type="button"
                  onClick={() => handleDeleteBrand(b)}
                  className="p-1 text-slate-400 hover:text-rose-400"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. SPECIFICATIONS MANAGER */}
      {activeCategory === 'specs' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-4">
          <form onSubmit={handleAddSpec} className="flex gap-2">
            <input
              type="text"
              placeholder="Add specification e.g. KSA, RB, RC, AGM, VRLA..."
              value={newSpecName}
              onChange={(e) => setNewSpecName(e.target.value)}
              className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white uppercase placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
            <button
              type="submit"
              disabled={!newSpecName.trim()}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-bold text-xs rounded-xl flex items-center gap-1 shrink-0"
            >
              <Plus className="w-4 h-4" /> Add Spec
            </button>
          </form>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
            {masterData.specifications.map((s, idx) => (
              <div
                key={s}
                className="flex items-center justify-between p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs"
              >
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-slate-400 font-mono">#{idx + 1}</span>
                  <span className="font-bold text-cyan-300">{s}</span>
                </div>
                <button
                  type="button"
                  onClick={() => handleDeleteSpec(s)}
                  className="p-1 text-slate-400 hover:text-rose-400"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. STATUS MANAGER (4 Types: DRY, MF, WET, Under Charging) */}
      {activeCategory === 'statuses' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-4">
          <form onSubmit={handleAddStatus} className="flex gap-2">
            <input
              type="text"
              placeholder="Add battery status e.g. DRY, MF, WET, Under Charging..."
              value={newStatusName}
              onChange={(e) => setNewStatusName(e.target.value)}
              className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
            <button
              type="submit"
              disabled={!newStatusName.trim()}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-bold text-xs rounded-xl flex items-center gap-1 shrink-0"
            >
              <Plus className="w-4 h-4" /> Add Status
            </button>
          </form>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {masterData.statuses.map((st, idx) => (
              <div
                key={st}
                className="flex items-center justify-between p-3 rounded-xl bg-slate-800 border border-slate-700 text-xs"
              >
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-slate-400 font-mono">#{idx + 1}</span>
                  <span className="font-bold text-slate-100">{st}</span>
                </div>
                <button
                  type="button"
                  onClick={() => handleDeleteStatus(st)}
                  className="p-1 text-slate-400 hover:text-rose-400"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 5. BOX COLOURS MANAGER (6 Types: Plain, Black, RED, Green, GOLD, Brown) */}
      {activeCategory === 'colours' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-4">
          <form onSubmit={handleAddColour} className="flex flex-wrap gap-2 items-center">
            <input
              type="text"
              placeholder="Colour name (e.g. Orange, White, Blue)"
              value={newColourName}
              onChange={(e) => setNewColourName(e.target.value)}
              className="flex-1 min-w-[140px] bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
            <div className="flex items-center gap-1.5 bg-slate-800 border border-slate-700 px-2 py-1 rounded-xl">
              <input
                type="color"
                value={newColourHex}
                onChange={(e) => setNewColourHex(e.target.value)}
                className="w-7 h-7 rounded border-none cursor-pointer bg-transparent"
              />
              <span className="font-mono text-xs text-slate-300">{newColourHex}</span>
            </div>
            <button
              type="submit"
              disabled={!newColourName.trim()}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-bold text-xs rounded-xl flex items-center gap-1 shrink-0"
            >
              <Plus className="w-4 h-4" /> Add Colour
            </button>
          </form>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {masterData.colours.map((col, idx) => (
              <div
                key={col.name}
                className="flex items-center justify-between p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs"
              >
                <div className="flex items-center gap-2">
                  <span 
                    className="w-4 h-4 rounded-full border border-black/40 shadow-xs" 
                    style={{ backgroundColor: col.hex }} 
                  />
                  <span className="font-bold text-slate-100">{col.name}</span>
                </div>
                <button
                  type="button"
                  onClick={() => handleDeleteColour(col.name)}
                  className="p-1 text-slate-400 hover:text-rose-400"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 6. AUDIT LOCATIONS MANAGER (3 to 4 Sites) */}
      {activeCategory === 'locations' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 space-y-4">
          <form onSubmit={handleAddLocation} className="grid grid-cols-1 sm:grid-cols-4 gap-2">
            <input
              type="text"
              placeholder="Location Name e.g. Depot 5"
              value={newLocName}
              onChange={(e) => setNewLocName(e.target.value)}
              className="sm:col-span-2 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
            <input
              type="text"
              placeholder="Code e.g. LOC-E"
              value={newLocCode}
              onChange={(e) => setNewLocCode(e.target.value)}
              className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
            <button
              type="submit"
              disabled={!newLocName.trim()}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1"
            >
              <Plus className="w-4 h-4" /> Add Location
            </button>
          </form>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {masterData.locations.map(loc => (
              <div
                key={loc.id}
                className="p-3 rounded-xl bg-slate-800 border border-slate-700 text-xs flex items-center justify-between"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-blue-400 bg-blue-950 px-2 py-0.5 rounded text-[10px] border border-blue-900">
                      {loc.code}
                    </span>
                    <span className="font-bold text-white text-sm">{loc.name}</span>
                  </div>
                  {loc.city && (
                    <p className="text-slate-400 text-[11px] mt-0.5">{loc.city}</p>
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => handleDeleteLocation(loc.id)}
                  className="p-1.5 text-slate-400 hover:text-rose-400"
                  title="Delete Location"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
