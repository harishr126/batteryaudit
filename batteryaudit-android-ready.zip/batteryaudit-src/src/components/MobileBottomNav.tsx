import React from 'react';
import { ClipboardList, BarChart3, Settings, Plus, Camera, MapPin } from 'lucide-react';

interface MobileBottomNavProps {
  activeTab: 'sheet' | 'compilation' | 'masters';
  setActiveTab: (tab: 'sheet' | 'compilation' | 'masters') => void;
  onAddEntry: () => void;
  onOpenScanner: () => void;
  currentLocName: string;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  activeTab,
  setActiveTab,
  onAddEntry,
  onOpenScanner,
  currentLocName
}) => {
  return (
    <div className="fixed bottom-0 inset-x-0 z-30 sm:hidden bg-slate-900/95 backdrop-blur-md border-t border-slate-800 px-3 py-1.5 shadow-2xl safe-area-pb">
      <div className="flex items-center justify-around relative">
        
        {/* Tab 1: Sheet */}
        <button
          type="button"
          onClick={() => setActiveTab('sheet')}
          className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-colors ${
            activeTab === 'sheet' ? 'text-blue-400 font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <ClipboardList className="w-5 h-5 mb-0.5" />
          <span className="text-[10px]">Sheet</span>
        </button>

        {/* Tab 2: Compilation */}
        <button
          type="button"
          onClick={() => setActiveTab('compilation')}
          className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-colors ${
            activeTab === 'compilation' ? 'text-blue-400 font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <BarChart3 className="w-5 h-5 mb-0.5" />
          <span className="text-[10px]">Compile</span>
        </button>

        {/* Center Floating Action Button (FAB) for Instant Data Entry */}
        <div className="relative -top-5 flex flex-col items-center">
          <button
            type="button"
            onClick={onAddEntry}
            className="w-14 h-14 rounded-full bg-gradient-to-tr from-blue-600 via-blue-500 to-indigo-600 text-white flex items-center justify-center shadow-xl shadow-blue-500/40 border-4 border-slate-900 active:scale-90 transition-transform"
            aria-label="Add New Battery Row"
          >
            <Plus className="w-7 h-7 stroke-[2.5]" />
          </button>
          <span className="text-[10px] font-extrabold text-blue-400 -mt-0.5">
            + ENTRY
          </span>
        </div>

        {/* Camera Barcode Scanner Quick Action */}
        <button
          type="button"
          onClick={onOpenScanner}
          className="flex flex-col items-center justify-center py-1 px-2 rounded-xl text-slate-400 hover:text-slate-200 transition-colors"
        >
          <Camera className="w-5 h-5 mb-0.5 text-cyan-400" />
          <span className="text-[10px]">Scan Barcode</span>
        </button>

        {/* Tab 4: Master Lists */}
        <button
          type="button"
          onClick={() => setActiveTab('masters')}
          className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-colors ${
            activeTab === 'masters' ? 'text-blue-400 font-bold' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Settings className="w-5 h-5 mb-0.5" />
          <span className="text-[10px]">Catalog</span>
        </button>

      </div>
    </div>
  );
};
