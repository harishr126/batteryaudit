import React, { useState } from 'react';
import { Calendar, ChevronLeft, ChevronRight, Check } from 'lucide-react';

interface MonthYearPickerProps {
  value: string; // MMM/YY e.g. OCT/24
  onChange: (value: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

const MONTHS = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];

// Parse current value (e.g. OCT/24)
const parseVal = (str: string) => {
  const parts = (str || '').split('/');
  const month = parts[0]?.toUpperCase() || 'OCT';
  const yearNum = parts[1] ? parseInt('20' + parts[1], 10) : new Date().getFullYear();
  return {
    month: MONTHS.includes(month) ? month : 'OCT',
    year: isNaN(yearNum) ? new Date().getFullYear() : yearNum
  };
};

export const MonthYearPicker: React.FC<MonthYearPickerProps> = ({ value, onChange, isOpen, onClose }) => {
  const initial = parseVal(value);
  const [selectedMonth, setSelectedMonth] = useState<string>(initial.month);
  const [selectedYear, setSelectedYear] = useState<number>(initial.year);

  // Sync state whenever opened or value changes
  React.useEffect(() => {
    if (isOpen) {
      const p = parseVal(value);
      setSelectedMonth(p.month);
      setSelectedYear(p.year);
    }
  }, [isOpen, value]);

  // Quick preset helper
  const getCurrentMonthStr = (offsetMonths: number = 0) => {
    const d = new Date();
    d.setMonth(d.getMonth() - offsetMonths);
    const m = MONTHS[d.getMonth()];
    const y = String(d.getFullYear()).slice(-2);
    return `${m}/${y}`;
  };

  const handleApply = (m: string, y: number) => {
    const yStr = String(y).slice(-2);
    onChange(`${m}/${yStr}`);
    onClose();
  };

  const handlePreset = (presetVal: string) => {
    onChange(presetVal);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div 
        className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-5 text-white animate-in fade-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-blue-400" />
            <h3 className="font-bold text-base text-slate-100">Month of Charge</h3>
          </div>
          <span className="text-xs font-mono font-bold bg-blue-950 text-blue-300 px-2.5 py-1 rounded-md border border-blue-800">
            Format: MMM/YY
          </span>
        </div>

        {/* Quick Presets for fast entry */}
        <div className="my-3">
          <p className="text-xs text-slate-400 mb-2">Quick Presets:</p>
          <div className="grid grid-cols-3 gap-1.5">
            <button
              type="button"
              onClick={() => handlePreset(getCurrentMonthStr(0))}
              className="px-2 py-1.5 text-xs font-semibold rounded-lg bg-blue-600/30 hover:bg-blue-600 text-blue-200 hover:text-white border border-blue-500/40 transition-colors"
            >
              Current ({getCurrentMonthStr(0)})
            </button>
            <button
              type="button"
              onClick={() => handlePreset(getCurrentMonthStr(1))}
              className="px-2 py-1.5 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
            >
              -1 Mo ({getCurrentMonthStr(1)})
            </button>
            <button
              type="button"
              onClick={() => handlePreset(getCurrentMonthStr(2))}
              className="px-2 py-1.5 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
            >
              -2 Mo ({getCurrentMonthStr(2)})
            </button>
          </div>
        </div>

        {/* Year Navigator */}
        <div className="flex items-center justify-between bg-slate-800/80 px-3 py-2 rounded-xl mb-3 border border-slate-700/60">
          <button
            type="button"
            onClick={() => setSelectedYear(y => y - 1)}
            className="p-1 rounded-lg hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <span className="font-bold font-mono text-base text-white tracking-wide">
            {selectedYear}
          </span>
          <button
            type="button"
            onClick={() => setSelectedYear(y => y + 1)}
            className="p-1 rounded-lg hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>

        {/* Month Grid */}
        <div className="grid grid-cols-4 gap-2 mb-4">
          {MONTHS.map(m => {
            const isSelected = selectedMonth === m;
            return (
              <button
                key={m}
                type="button"
                onClick={() => setSelectedMonth(m)}
                className={`py-2 px-1 text-xs font-bold rounded-xl transition-all ${
                  isSelected
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30 ring-2 ring-blue-400'
                    : 'bg-slate-800/90 text-slate-300 hover:bg-slate-700 hover:text-white border border-slate-700/50'
                }`}
              >
                {m}
              </button>
            );
          })}
        </div>

        {/* Selected Preview & Confirm */}
        <div className="flex items-center justify-between pt-3 border-t border-slate-800">
          <div className="text-xs text-slate-400">
            Selected: <span className="text-white font-mono font-bold text-sm">{selectedMonth}/{String(selectedYear).slice(-2)}</span>
          </div>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-2 text-xs font-semibold text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={() => handleApply(selectedMonth, selectedYear)}
              className="px-4 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 rounded-lg flex items-center gap-1.5 shadow-lg shadow-blue-600/20 transition-all active:scale-95"
            >
              <Check className="w-4 h-4" /> Apply Date
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
