import * as XLSX from 'xlsx';
import { BatteryEntry, LocationInfo } from '../types/battery';
import { deliverFile, XLSX_MIME } from './nativeFile';

const reportExportError = (err: unknown) => {
  console.error('Export failed:', err);
  alert('Export failed: ' + ((err as any)?.message || 'could not save file'));
};

const saveWorkbook = (workbook: XLSX.WorkBook, fileName: string): void => {
  const base64 = XLSX.write(workbook, { type: 'base64', bookType: 'xlsx' });
  deliverFile({ fileName, mimeType: XLSX_MIME, base64 }).catch(reportExportError);
};


export class ExcelService {
  /**
   * Export single location or filtered list into Excel with exact requested columns:
   * Sr no | Battery Type | Brand | Specification | Qty no's | Status | Colour | production code | Month of charge | Remarks
   */
  static exportToExcel(entries: BatteryEntry[], sheetName: string = 'Battery Data Collection', includeLocationCol: boolean = false): void {
    const rows = entries.map((e, index) => {
      const baseRow: Record<string, any> = {
        'Sr no': e.srNo || (index + 1),
        'Battery Type': e.batteryType || '',
        'Brand': e.brand || '',
        'Specification': e.specification || '',
        'Qty no\'s': Number(e.qty) || 0,
        'Status': e.status || '',
        'Colour': e.colour || '',
        'production code': e.productionCode || '',
        'Month of charge': e.monthOfCharge || '',
        'Remarks': e.remarks || ''
      };

      if (includeLocationCol) {
        return {
          ...baseRow,
          'Location': e.locationName || e.locationId || ''
        };
      }
      return baseRow;
    });

    const worksheet = XLSX.utils.json_to_sheet(rows);

    // Set standard column widths for nice readability
    worksheet['!cols'] = [
      { wch: 8 },  // Sr no
      { wch: 18 }, // Battery Type
      { wch: 16 }, // Brand
      { wch: 18 }, // Specification
      { wch: 10 }, // Qty no's
      { wch: 22 }, // Status
      { wch: 12 }, // Colour
      { wch: 18 }, // production code
      { wch: 16 }, // Month of charge
      { wch: 30 }, // Remarks
      ...(includeLocationCol ? [{ wch: 26 }] : [])
    ];

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, sheetName.substring(0, 31));

    const dateStr = new Date().toISOString().slice(0, 10);
    const fileName = `${sheetName.replace(/[^a-zA-Z0-9_-]/g, '_')}_${dateStr}.xlsx`;
    saveWorkbook(workbook, fileName);
  }

  /**
   * Export comprehensive multi-location compilation workbook:
   * 1. Consolidated Master Sheet (All locations)
   * 2. Individual Location tabs (Location 1, Location 2, Location 3, Location 4...)
   * 3. Aggregated Pivot Table (Battery Type vs Specs & Locations)
   */
  static exportCompilationWorkbook(entries: BatteryEntry[], locations: LocationInfo[]): void {
    const workbook = XLSX.utils.book_new();

    // 1. Consolidated Sheet
    const masterRows = entries.map((e, index) => ({
      'Sr no': index + 1,
      'Location': e.locationName || e.locationId,
      'Battery Type': e.batteryType,
      'Brand': e.brand,
      'Specification': e.specification,
      'Qty no\'s': Number(e.qty) || 0,
      'Status': e.status,
      'Colour': e.colour,
      'production code': e.productionCode,
      'Month of charge': e.monthOfCharge,
      'Remarks': e.remarks
    }));

    const masterSheet = XLSX.utils.json_to_sheet(masterRows);
    masterSheet['!cols'] = [
      { wch: 8 },  // Sr no
      { wch: 28 }, // Location
      { wch: 18 }, // Battery Type
      { wch: 16 }, // Brand
      { wch: 18 }, // Specification
      { wch: 10 }, // Qty
      { wch: 22 }, // Status
      { wch: 12 }, // Colour
      { wch: 18 }, // production code
      { wch: 16 }, // Month of charge
      { wch: 30 }  // Remarks
    ];
    XLSX.utils.book_append_sheet(workbook, masterSheet, 'All Locations Master');

    // 2. Individual sheets per location
    locations.forEach(loc => {
      const locEntries = entries.filter(e => e.locationId === loc.id);
      if (locEntries.length > 0) {
        const locRows = locEntries.map((e, index) => ({
          'Sr no': e.srNo || (index + 1),
          'Battery Type': e.batteryType,
          'Brand': e.brand,
          'Specification': e.specification,
          'Qty no\'s': Number(e.qty) || 0,
          'Status': e.status,
          'Colour': e.colour,
          'production code': e.productionCode,
          'Month of charge': e.monthOfCharge,
          'Remarks': e.remarks
        }));

        const locSheet = XLSX.utils.json_to_sheet(locRows);
        locSheet['!cols'] = [
          { wch: 8 },
          { wch: 18 },
          { wch: 16 },
          { wch: 18 },
          { wch: 10 },
          { wch: 22 },
          { wch: 12 },
          { wch: 18 },
          { wch: 16 },
          { wch: 30 }
        ];
        // Sheet names in Excel cannot exceed 31 chars or contain : \ / ? * [ ]
        const cleanName = (loc.code || loc.name).replace(/[:\\/?*[\]]/g, '-').substring(0, 31);
        XLSX.utils.book_append_sheet(workbook, locSheet, cleanName);
      }
    });

    // 3. Summary Pivot Sheet
    const typeSummaryMap = new Map<string, {
      batteryType: string;
      specification: string;
      brand: string;
      totalQty: number;
      locCounts: Record<string, number>;
    }>();

    entries.forEach(e => {
      const key = `${e.batteryType}___${e.specification}___${e.brand}`;
      if (!typeSummaryMap.has(key)) {
        typeSummaryMap.set(key, {
          batteryType: e.batteryType,
          specification: e.specification,
          brand: e.brand,
          totalQty: 0,
          locCounts: {}
        });
      }
      const item = typeSummaryMap.get(key)!;
      const q = Number(e.qty) || 0;
      item.totalQty += q;
      const locLabel = e.locationName || e.locationId || 'Unknown';
      item.locCounts[locLabel] = (item.locCounts[locLabel] || 0) + q;
    });

    const summaryRows = Array.from(typeSummaryMap.values()).map(s => {
      const row: Record<string, any> = {
        'Battery Type': s.batteryType,
        'Brand': s.brand,
        'Specification': s.specification,
        'Total Quantity': s.totalQty
      };
      locations.forEach(l => {
        row[l.name] = s.locCounts[l.name] || 0;
      });
      return row;
    });

    const summarySheet = XLSX.utils.json_to_sheet(summaryRows);
    XLSX.utils.book_append_sheet(workbook, summarySheet, 'Summary Totals Pivot');

    const dateStr = new Date().toISOString().slice(0, 10);
    saveWorkbook(workbook, `Multi_Location_Battery_Audit_Compiled_${dateStr}.xlsx`);
  }

  /**
   * Export to standard CSV format
   */
  static exportToCSV(entries: BatteryEntry[], filenamePrefix: string = 'Battery_Audit'): void {
    const headers = [
      'Sr no',
      'Battery Type',
      'Brand',
      'Specification',
      'Qty no\'s',
      'Status',
      'Colour',
      'production code',
      'Month of charge',
      'Remarks',
      'Location'
    ];

    const escapeCsv = (str: string | number) => {
      const s = String(str ?? '');
      if (s.includes(',') || s.includes('"') || s.includes('\n')) {
        return `"${s.replace(/"/g, '""')}"`;
      }
      return s;
    };

    const csvLines = [headers.join(',')];
    entries.forEach((e, index) => {
      csvLines.push([
        escapeCsv(e.srNo || index + 1),
        escapeCsv(e.batteryType),
        escapeCsv(e.brand),
        escapeCsv(e.specification),
        escapeCsv(e.qty),
        escapeCsv(e.status),
        escapeCsv(e.colour),
        escapeCsv(e.productionCode),
        escapeCsv(e.monthOfCharge),
        escapeCsv(e.remarks),
        escapeCsv(e.locationName)
      ].join(','));
    });

    deliverFile({
      fileName: `${filenamePrefix}_${new Date().toISOString().slice(0, 10)}.csv`,
      mimeType: 'text/csv;charset=utf-8;',
      text: '\uFEFF' + csvLines.join('\n')
    }).catch(reportExportError);
  }

  /**
   * Parse uploaded Excel (.xlsx, .xls) or CSV file into BatteryEntry objects
   */
  static async parseFile(file: File, defaultLocationId: string, defaultLocationName: string): Promise<BatteryEntry[]> {
    const buffer = await file.arrayBuffer();
    const workbook = XLSX.read(buffer, { type: 'array' });
    const firstSheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[firstSheetName];
    const rawData = XLSX.utils.sheet_to_json<Record<string, any>>(worksheet);

    const parsed: BatteryEntry[] = [];
    const now = new Date().toISOString();

    rawData.forEach((row, i) => {
      // Find matching keys case-insensitively
      const findVal = (keys: string[]): string => {
        for (const k of keys) {
          const matchedKey = Object.keys(row).find(rk => rk.trim().toLowerCase() === k.toLowerCase());
          if (matchedKey && row[matchedKey] !== undefined && row[matchedKey] !== null) {
            return String(row[matchedKey]).trim();
          }
        }
        return '';
      };

      const batteryType = findVal(['Battery Type', 'BatteryType', 'Type']);
      if (!batteryType) return; // skip empty rows

      const srNoVal = Number(findVal(['Sr no', 'Sr no.', 'Serial No', 'Sr'])) || (i + 1);
      const brand = findVal(['Brand', 'Make']) || 'Unknown';
      const specification = findVal(['Specification', 'Spec']) || 'MF';
      const qtyVal = Number(findVal(['Qty no\'s', 'Qty', 'Quantity', 'Qty nos'])) || 1;
      const status = findVal(['Status', 'Battery Status']) || 'Normal In-Stock';
      const colour = findVal(['Colour', 'Color', 'Box Color']) || 'Black';
      const productionCode = findVal(['production code', 'Production Code', 'Prod Code', 'Serial']);
      const monthOfCharge = findVal(['Month of charge', 'MonthOfCharge', 'Charge Month']) || 'OCT/24';
      const remarks = findVal(['Remarks', 'Notes', 'Comment']);
      const locationName = findVal(['Location', 'Location Name']) || defaultLocationName;

      parsed.push({
        id: 'imported-' + Date.now() + '-' + i + '-' + Math.random().toString(36).substring(2, 6),
        srNo: srNoVal,
        batteryType,
        brand,
        specification,
        qty: qtyVal,
        status,
        colour,
        productionCode,
        monthOfCharge,
        remarks,
        locationId: defaultLocationId,
        locationName,
        createdAt: now,
        updatedAt: now
      });
    });

    return parsed;
  }
}
