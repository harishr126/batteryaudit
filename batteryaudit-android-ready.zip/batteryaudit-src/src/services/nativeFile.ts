import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';

export const isNativeApp = (): boolean => Capacitor.isNativePlatform();

interface DeliverOptions {
  fileName: string;
  mimeType: string;
  /** Plain text content (csv / json). Provide this OR base64. */
  text?: string;
  /** Base64 content for binary files (xlsx). */
  base64?: string;
}

/**
 * Android WebViews ignore `<a download>` and XLSX.writeFile, so on the native app
 * we write the file to app cache and open the system share sheet
 * (Save to Drive / Files, WhatsApp, Email, Bluetooth, etc.).
 * In a normal browser we fall back to a classic download.
 */
export async function deliverFile(opts: DeliverOptions): Promise<void> {
  const { fileName, mimeType, text, base64 } = opts;

  if (isNativeApp()) {
    const written = await Filesystem.writeFile(
      base64 !== undefined
        ? { path: fileName, data: base64, directory: Directory.Cache }
        : { path: fileName, data: text ?? '', directory: Directory.Cache, encoding: Encoding.UTF8 }
    );
    try {
      await Share.share({
        title: fileName,
        dialogTitle: 'Save or share ' + fileName,
        url: written.uri
      });
    } catch (err: any) {
      // User dismissing the share sheet is not an error.
      const msg = String(err?.message || err).toLowerCase();
      if (!msg.includes('cancel')) throw err;
    }
    return;
  }

  let blob: Blob;
  if (base64 !== undefined) {
    const bin = atob(base64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    blob = new Blob([bytes], { type: mimeType });
  } else {
    blob = new Blob([text ?? ''], { type: mimeType });
  }
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export const XLSX_MIME = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
