import { Capacitor } from '@capacitor/core';
import { StatusBar, Style } from '@capacitor/status-bar';
import { SplashScreen } from '@capacitor/splash-screen';

/** One-time setup when running inside the Android app. No-op in a browser. */
export async function initNativeShell(): Promise<void> {
  if (!Capacitor.isNativePlatform()) return;
  try {
    await StatusBar.setStyle({ style: Style.Dark }); // light icons on the dark header
    if (Capacitor.getPlatform() === 'android') {
      await StatusBar.setBackgroundColor({ color: '#0f172a' });
    }
  } catch (e) {
    console.warn('StatusBar setup skipped:', e);
  }
  try {
    await SplashScreen.hide();
  } catch {
    // ignore
  }
}
