import { BatteryEntry, MasterData } from '../types/battery';
import { INITIAL_MASTER_DATA, INITIAL_SAMPLE_ENTRIES } from '../data/defaultMasters';

const STORAGE_KEYS = {
  ENTRIES: 'batteryaudit_entries_v1',
  MASTER_DATA: 'batteryaudit_master_v1',
  ACTIVE_LOCATION: 'batteryaudit_active_loc_v1',
  AUDITOR_NAME: 'batteryaudit_auditor_name_v1'
};

export class StorageService {
  static getMasterData(): MasterData {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.MASTER_DATA);
      if (data) {
        return JSON.parse(data);
      }
    } catch (e) {
      console.warn('Failed to load master data from localStorage:', e);
    }
    this.saveMasterData(INITIAL_MASTER_DATA);
    return INITIAL_MASTER_DATA;
  }

  static saveMasterData(masterData: MasterData): void {
    try {
      localStorage.setItem(STORAGE_KEYS.MASTER_DATA, JSON.stringify(masterData));
    } catch (e) {
      console.error('Failed to save master data:', e);
    }
  }

  static getEntries(): BatteryEntry[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.ENTRIES);
      if (data) {
        const parsed = JSON.parse(data);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.warn('Failed to load entries from localStorage:', e);
    }
    // Seed default samples if empty
    this.saveEntries(INITIAL_SAMPLE_ENTRIES);
    return INITIAL_SAMPLE_ENTRIES;
  }

  static saveEntries(entries: BatteryEntry[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.ENTRIES, JSON.stringify(entries));
    } catch (e) {
      console.error('Failed to save entries:', e);
    }
  }

  static getNextSrNo(locationId: string): number {
    const entries = this.getEntries().filter(e => e.locationId === locationId);
    if (entries.length === 0) return 1;
    const maxSr = Math.max(...entries.map(e => e.srNo || 0));
    return maxSr + 1;
  }

  static addEntry(entry: Omit<BatteryEntry, 'id' | 'createdAt' | 'updatedAt'>): BatteryEntry {
    const entries = this.getEntries();
    const now = new Date().toISOString();
    const newEntry: BatteryEntry = {
      ...entry,
      id: 'bat-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
      createdAt: now,
      updatedAt: now
    };
    entries.push(newEntry);
    this.saveEntries(entries);
    return newEntry;
  }

  static updateEntry(id: string, updates: Partial<BatteryEntry>): BatteryEntry | null {
    const entries = this.getEntries();
    const index = entries.findIndex(e => e.id === id);
    if (index === -1) return null;
    const updated: BatteryEntry = {
      ...entries[index],
      ...updates,
      updatedAt: new Date().toISOString()
    };
    entries[index] = updated;
    this.saveEntries(entries);
    return updated;
  }

  static deleteEntry(id: string): boolean {
    const entries = this.getEntries();
    const filtered = entries.filter(e => e.id !== id);
    if (filtered.length === entries.length) return false;
    this.saveEntries(filtered);
    return true;
  }

  static deleteMultipleEntries(ids: string[]): void {
    const idSet = new Set(ids);
    const entries = this.getEntries().filter(e => !idSet.has(e.id));
    this.saveEntries(entries);
  }

  static getActiveLocationId(): string {
    return localStorage.getItem(STORAGE_KEYS.ACTIVE_LOCATION) || 'loc-1';
  }

  static setActiveLocationId(id: string): void {
    localStorage.setItem(STORAGE_KEYS.ACTIVE_LOCATION, id);
  }

  static getAuditorName(): string {
    return localStorage.getItem(STORAGE_KEYS.AUDITOR_NAME) || 'Inspector';
  }

  static setAuditorName(name: string): void {
    localStorage.setItem(STORAGE_KEYS.AUDITOR_NAME, name);
  }

  // Multi-location compilation & merge
  static mergeExternalEntries(incomingEntries: BatteryEntry[]): { added: number; updated: number } {
    const existing = this.getEntries();
    const existingMap = new Map<string, BatteryEntry>();
    existing.forEach(e => existingMap.set(e.id, e));

    let added = 0;
    let updated = 0;

    incomingEntries.forEach(incoming => {
      // If same id exists, update it if incoming is newer or distinct
      if (existingMap.has(incoming.id)) {
        existingMap.set(incoming.id, incoming);
        updated++;
      } else {
        // Check if there is an exact match on location, productionCode, batteryType
        if (incoming.productionCode && incoming.productionCode.trim()) {
          const match = existing.find(
            e => e.locationId === incoming.locationId &&
                 e.productionCode.toLowerCase() === incoming.productionCode.toLowerCase()
          );
          if (match) {
            existingMap.set(match.id, { ...incoming, id: match.id });
            updated++;
            return;
          }
        }
        // Brand new entry
        existingMap.set(incoming.id || ('bat-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7)), incoming);
        added++;
      }
    });

    const merged = Array.from(existingMap.values());
    this.saveEntries(merged);
    return { added, updated };
  }

  static resetToDefault(): void {
    this.saveEntries(INITIAL_SAMPLE_ENTRIES);
    this.saveMasterData(INITIAL_MASTER_DATA);
  }

  static clearAllEntries(): void {
    this.saveEntries([]);
  }
}
