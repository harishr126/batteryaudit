export interface BatteryEntry {
  id: string;
  srNo: number; // Sr no - 1-based sequential number
  batteryType: string; // e.g. N50 MF, NS40 MF, 12N24-3 MF
  brand: string; // e.g. Charger Gold, Powerpack, Reem
  specification: string; // e.g. RB MF, RC, DC, MF
  qty: number; // Qty no's (integer >= 0)
  status: string; // 4 status types e.g. Fresh, In-Stock, Recharge Needed, Discharged
  colour: string; // 6 colour types e.g. Red, White, Black, Blue, Grey, Yellow
  productionCode: string; // identification code alphanumeric
  monthOfCharge: string; // format MMM/YY e.g. OCT/24
  remarks: string; // optional user remarks
  locationId: string; // identifier of the collection location
  locationName: string; // human readable location name
  auditorName?: string; // name of the staff collecting data
  createdAt: string; // ISO date
  updatedAt: string; // ISO date
}

export interface BoxColour {
  name: string;
  hex: string;
  border?: boolean;
}

export interface LocationInfo {
  id: string;
  name: string;
  code: string;
  city?: string;
  description?: string;
}

export interface MasterData {
  batteryTypes: string[];
  specifications: string[];
  brands: string[];
  statuses: string[];
  colours: BoxColour[];
  locations: LocationInfo[];
}

export interface FilterState {
  search: string;
  locationId: string; // 'ALL' or specific id
  batteryType: string;
  brand: string;
  specification: string;
  status: string;
  colour: string;
  monthOfCharge: string;
}

export interface CompilationSummary {
  totalRecords: number;
  totalQuantity: number;
  byLocation: {
    locationId: string;
    locationName: string;
    recordCount: number;
    totalQuantity: number;
  }[];
  byStatus: {
    status: string;
    count: number;
    quantity: number;
  }[];
  byBrand: {
    brand: string;
    count: number;
    quantity: number;
  }[];
  byColour: {
    colour: string;
    count: number;
    quantity: number;
  }[];
  byType: {
    batteryType: string;
    specification: string;
    quantity: number;
    locations: { [locName: string]: number };
  }[];
}
